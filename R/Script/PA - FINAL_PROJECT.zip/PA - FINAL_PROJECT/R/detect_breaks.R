# R/detect_breaks.R

detect_break_qlr <- function(df, value_col = "value", trim = 0.15) {
  ts_y <- ts(df[[value_col]],
    start = c(
      as.numeric(format(min(df$date), "%Y")),
      as.numeric(format(min(df$date), "%m"))
    ),
    frequency = 12
  )
  qlr <- strucchange::Fstats(ts_y ~ 1, from = trim)
  test <- strucchange::sctest(qlr, type = "supF")
  bp <- strucchange::breakpoints(qlr)$breakpoints
  list(
    break_date = df$date[bp],
    statistic  = unname(test$statistic),
    p_value    = unname(test$p.value),
    qlr        = qlr
  )
}


detect_breaks_bp <- function(df, value_col = "value", h = 0.15,
                             breaks = NULL) {
  ts_y <- ts(df[[value_col]],
    start = c(
      as.numeric(format(min(df$date), "%Y")),
      as.numeric(format(min(df$date), "%m"))
    ),
    frequency = 12
  )

  bp <- strucchange::breakpoints(ts_y ~ 1, h = h, breaks = breaks)
  idx <- bp$breakpoints
  ci <- tryCatch(
    suppressWarnings(confint(bp)$confint),
    error = function(e) NULL
  )

  list(
    break_dates = if (any(is.na(idx))) as.Date(character()) else df$date[idx],
    n_breaks    = if (any(is.na(idx))) 0L else length(idx),
    bic         = BIC(bp),
    ci          = ci,
    bp          = bp
  )
}

#' --- Outlier-based breakpoint detection ----------------------------------- 80
#'
#' Detect transitory and permanent anomalies using tsoutliers::tso().
#' This treats COVID-era inflation as a temporary change (TC) rather than
#' a permanent level shift, which better matches the shape of the series.
#'
detect_outliers_tso <- function(df, value_col = "d1_value",
                                types = c("AO", "LS", "TC"),
                                tsbox_freq = 12,
                                delta = 0.9, cval = 3.5) {
  y <- ts(df[[value_col]],
    start = c(
      lubridate::year(min(df$date)),
      lubridate::month(min(df$date))
    ),
    frequency = tsbox_freq
  )

  fit <- tsoutliers::tso(
    y,
    types = types,
    delta = delta,
    cval = cval,
    maxit.iloop = 10,
    maxit.oloop = 10,
    tsmethod = "auto.arima"
  )

  # The regressor matrix is built by outliers.effects(), not stored at top level
  xreg <- if (!is.null(fit$outliers) && nrow(fit$outliers) > 0) {
    tsoutliers::outliers.effects(
      fit$outliers,
      n = length(y),
      delta = delta
    )
  } else {
    NULL
  }

  list(
    fit = fit,
    outliers = fit$outliers,
    xreg = xreg,
    dates = if (!is.null(fit$outliers) && nrow(fit$outliers) > 0) {
      df$date[fit$outliers$ind]
    } else {
      as.Date(character(0))
    }
  )
}
