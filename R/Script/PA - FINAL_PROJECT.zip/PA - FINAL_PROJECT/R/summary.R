# R/summary.R
.data <- rlang::.data

#' Basic timeseries summary
#' @param df Long-format dataframe to be summarized based on series_id
#' @param value_col Name of the column to summarise (default "value")
#' @return tibble containing summary statistics
std_summary <- function(df, value_col = "value") {
  df |>
    dplyr::group_by(.data$series_id) |>
    dplyr::summarise(
      country   = dplyr::first(.data$country),
      indicator = dplyr::first(.data$indicator),
      min_date  = min(.data$date),
      max_date  = max(.data$date),
      num_na    = sum(is.na(.data[[value_col]])),
      avg       = round(mean(.data[[value_col]], na.rm = TRUE), 2),
      var       = round(stats::var(.data[[value_col]], na.rm = TRUE), 2)
    ) |>
    dplyr::select(-.data$series_id)
}

#' Summarise stationarity tests (ADF + KPSS) for a long-format tibble
#'
#' Deterministic regressors are controlled by two switches:
#' \itemize{
#'   \item \code{level}: include a constant. Almost always TRUE.
#'   \item \code{trend}: include a linear time trend. Use for series that
#'     could plausibly drift (price levels, GDP). Leave FALSE for rates.
#' }
#'
#' @param df Long-format tibble with columns: series_id, date, value
#' @param value_col Name of the column to test (default "value")
#' @param min_obs Minimum non-missing observations required to run tests
#' @param level Include intercept in test regressions (default TRUE)
#' @param trend Include linear trend (default FALSE)
#' @return Tibble with one row per series_id
stationary_ts_summary <- function(df, value_col = "value",
                                  min_obs = 24,
                                  level = TRUE, trend = FALSE) {
  ts_tests <- function(x) {
    x <- x[is.finite(x)]

    na_row <- tibble::tibble(
      adf_stat  = NA_real_, adf_p  = NA_real_,
      kpss_stat = NA_real_, kpss_p = NA_real_
    )

    if (length(x) < min_obs || stats::sd(x) == 0) {
      return(na_row)
    }

    # --- ADF via urca::ur.df ---
    adf_type <- if (trend) "trend" else if (level) "drift" else "none"
    adf <- tryCatch(
      suppressWarnings(urca::ur.df(x, type = adf_type, selectlags = "AIC")),
      error = function(e) NULL
    )

    # --- KPSS ---
    kpss_null <- if (trend) "Trend" else "Level"
    kpss <- tryCatch(
      suppressWarnings(tseries::kpss.test(x, null = kpss_null)),
      error = function(e) NULL
    )

    if (is.null(adf) || is.null(kpss)) {
      return(na_row)
    }

    # urca returns a critical-value table; interpolate to an approximate p-value
    adf_stat <- adf@teststat[1, "tau1"]
    cv <- adf@cval["tau1", ] # 1pct, 5pct, 10pct
    adf_p <- stats::approx(
      x = cv, y = c(0.01, 0.05, 0.10),
      xout = adf_stat, rule = 2
    )$y

    tibble::tibble(
      adf_stat  = round(unname(adf_stat), 3),
      adf_p     = round(unname(adf_p), 3),
      kpss_stat = round(unname(kpss$statistic), 3),
      kpss_p    = round(kpss$p.value, 3)
    )
  }

  df |>
    dplyr::group_by(.data$series_id) |>
    dplyr::reframe(
      country   = dplyr::first(.data$country),
      indicator = dplyr::first(.data$indicator),
      ts_tests(.data[[value_col]])
    ) |>
    dplyr::select(-.data$series_id)
}
