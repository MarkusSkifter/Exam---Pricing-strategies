# R/transform.R
.data <- rlang::.data

#' Add a differenced column to a long-format series tibble
#'
#' For each series_id, computes the lag-`lag` difference of `value_col`,
#' optionally on the log scale. Leading rows (where the lag isn't defined)
#' get NA.
#'
#' @param df Long-format tibble with columns: series_id, date, and `value_col`
#' @param lag Integer lag for the difference (1 = period-over-period,
#'   12 = year-over-year for monthly data)
#' @param log If TRUE, take log() before differencing (so the result
#'   approximates a growth rate)
#' @param value_col Name of the input column (default "value")
#' @param new_col Name of the output column (default "transformed")
#' @return `df` with one extra column named `new_col`
#'
difference_series <- function(df, lag = 1, log = FALSE,
                              value_col = "value",
                              new_col = "transformed") {
  df |>
    dplyr::arrange(.data$series_id, .data$date) |>
    dplyr::group_by(.data$series_id) |>
    dplyr::mutate(
      !!new_col := {
        v <- .data[[value_col]]
        if (log) {
          # Guard: log is only defined for strictly positive values
          bad <- !is.na(v) & v <= 0
          if (any(bad)) {
            warning(
              sprintf(
                "series_id '%s': %d non-positive value(s) set to NA before log()",
                dplyr::cur_group()$series_id, sum(bad)
              ),
              call. = FALSE
            )
            v[bad] <- NA_real_
          }
          v <- log(v)
        }
        d <- v - dplyr::lag(v, n = lag)
        # Normalize any Inf/-Inf/NaN to NA so downstream na.omit() catches them
        d[!is.finite(d)] <- NA_real_
        d
      }
    ) |>
    dplyr::ungroup()
}
