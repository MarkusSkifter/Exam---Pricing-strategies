# R/arima_with_break.R
#
# Helpers for fitting an ARIMA model with one or more known break dates.
#
# Workflow:
#   1. make_break_xreg()      -> build regressors (level shift / TC / AO)
#   2. select_arima_order()   -> let auto.arima pick (p,q,P,Q) with xreg
#   3. fit_arima_with_break() -> fit the final model and return diagnostics
#
# Assumes: df has a `date` column (Date), monthly frequency, and is already
#          differenced if you want d = 0. The column to model is chosen via
#          `value_col`.
# --------------------------------------------------------------------------- 80
# 1. Build regressors for one or more breaks
# --------------------------------------------------------------------------- 80
# break_dates: Date(s) marking the START of each break
# end_dates  : Date(s) marking the END of each break (only used for "WIN" type;
#              ignored otherwise). Must be same length as break_dates or NULL.
# type       : single string or vector matching break_dates.
#              Allowed: "LS", "TC", "AO", "WIN".
#   "LS"  : level shift   (0 before break, 1 from break onward)
#   "TC"  : transient change (spike at break, decays at rate `decay`)
#   "AO"  : additive outlier (1 only at the break month)
#   "WIN" : window indicator (1 between break_date and end_date, 0 elsewhere)
make_break_xreg <- function(dates, break_dates, type = "TC",
                            decay = 0.95, end_dates = NULL) {
  break_dates <- as.Date(break_dates)
  n <- length(dates)
  nb <- length(break_dates)
  if (length(type) == 1) type <- rep(type, nb)
  if (length(type) != nb) {
    stop("`type` must have length 1 or length(break_dates)")
  }
  if (!all(type %in% c("LS", "TC", "AO", "WIN"))) {
    stop("`type` must be one of 'LS', 'TC', 'AO', 'WIN'")
  }
  if (any(type == "WIN")) {
    if (is.null(end_dates)) {
      stop("`end_dates` must be supplied when type includes 'WIN'")
    }
    end_dates <- as.Date(end_dates)
    if (length(end_dates) != nb) {
      stop("`end_dates` must have the same length as `break_dates`")
    }
  }

  cols <- lapply(seq_len(nb), function(i) {
    pos <- which(dates >= break_dates[i])[1]
    if (is.na(pos)) {
      stop(sprintf(
        "break_date %s is after the end of the series",
        break_dates[i]
      ))
    }
    x <- numeric(n)
    if (type[i] == "LS") {
      x[pos:n] <- 1
    } else if (type[i] == "AO") {
      x[pos] <- 1
    } else if (type[i] == "TC") {
      x[pos:n] <- decay^seq(0, n - pos)
    } else if (type[i] == "WIN") {
      x <- as.numeric(dates >= break_dates[i] & dates <= end_dates[i])
    }
    x
  })

  X <- do.call(cbind, cols)
  # Column names like "WIN_2021-04-01" so coefficients are easy to identify
  colnames(X) <- sprintf("%s_%s", type, format(break_dates))
  X
}

# --------------------------------------------------------------------------- 80
# 2. Select ARIMA order with the break regressor included
# --------------------------------------------------------------------------- 80
# Set d = 0 if your data is already differenced.
select_arima_order <- function(df, xreg, value_col = "value",
                               d = 0, D = 0, frequency = 12) {
  y <- ts(df[[value_col]],
    start = c(
      as.numeric(format(min(df$date), "%Y")),
      as.numeric(format(min(df$date), "%m"))
    ),
    frequency = frequency
  )
  forecast::auto.arima(
    y,
    xreg = xreg,
    d = d,
    D = D,
    max.order = 10,
    seasonal = TRUE,
    stepwise = FALSE,
    approximation = FALSE,
    trace = TRUE,
    allowdrift = FALSE,
    allowmean = FALSE,
    ic = "aicc"
  )
}
# --------------------------------------------------------------------------- 80
# 3. Baseline arima
# --------------------------------------------------------------------------- 80
fit_arima_baseline <- function(df, value_col = "value", d = 0, D = 0) {
  fit <- select_arima_order(df,
    xreg = NULL, value_col = value_col,
    d = d, D = D
  )
  ord <- forecast::arimaorder(fit)
  resi <- residuals(fit)
  k <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)

  list(
    fit = fit,
    order = ord,
    aicc = fit$aicc,
    ljung_box_12 = Box.test(resi,
      lag = 12, type = "Ljung-Box",
      fitdf = k
    )$p.value,
    ljung_box_24 = Box.test(resi,
      lag = 24, type = "Ljung-Box",
      fitdf = k
    )$p.value
  )
}


# --------------------------------------------------------------------------- 80
# 4. Fit and return a tidy summary
# --------------------------------------------------------------------------- 80
# break_dates: scalar or vector of dates
# type       : single string or vector matching length of break_dates
fit_arima_with_break <- function(df, break_dates, value_col = "value",
                                 type = "TC", d = 0, D = 0,
                                 end_dates = NULL) {
  xreg <- make_break_xreg(df$date, break_dates,
    type = type, end_dates = end_dates
  )
  print(xreg)
  fit <- select_arima_order(df, xreg, value_col = value_col, d = d, D = D)
  ord <- forecast::arimaorder(fit)
  resi <- residuals(fit)
  k <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)

  list(
    fit = fit,
    order = ord,
    break_coefs = coef(fit)[colnames(xreg)],
    aicc = fit$aicc,
    ljung_box_12 = Box.test(resi,
      lag = 12, type = "Ljung-Box",
      fitdf = k
    )$p.value,
    ljung_box_24 = Box.test(resi,
      lag = 24, type = "Ljung-Box",
      fitdf = k
    )$p.value
  )
}
