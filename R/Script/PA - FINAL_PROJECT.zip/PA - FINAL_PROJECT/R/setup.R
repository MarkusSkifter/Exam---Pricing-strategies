# R/setup.R

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(readr)
  library(purrr)
  library(fredr)
  library(ggpmisc)
  library(tseries)
  library(tsibble)
  library(uroot)
  library(strucchange)
  library(tsoutliers)
  library(gets)
})


# Load all project functions
for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) {
  if (f != "R/setup.R") {
    source(f)
  }
}


fred_ids <- c(
  "LRHUADTTEZM156N", # Eurozone unemployment
  "CP0000EZ19M086NEST" # Eurozone HICP
)
