# R/plot_covid_window.R
#
# Visualize a date-window dummy overlaid on a time series.
# Two helpers:
#   build_covid_window() - returns 0/1 indicator vector for a date range
#   plot_covid_window()  - ggplot of the series with the window shaded
#                          and the dummy drawn as a scaled line

build_covid_window <- function(dates,
                               start_date = as.Date("2021-04-01"),
                               end_date = as.Date("2023-12-31")) {
  as.numeric(dates >= as.Date(start_date) & dates <= as.Date(end_date))
}

plot_covid_window <- function(df,
                              value_col = "value",
                              date_col = "date",
                              start_date = as.Date("2021-04-01"),
                              end_date = as.Date("2023-12-31"),
                              title = "Series with COVID window") {
  dates <- df[[date_col]]
  values <- df[[value_col]]
  dummy <- build_covid_window(dates, start_date, end_date)

  # Scale dummy so its peak sits at the top of the data range
  scale_factor <- if (any(dummy == 1)) {
    max(abs(values), na.rm = TRUE) * 0.9
  } else {
    1
  }
  plot_df <- data.frame(
    date  = dates,
    value = values,
    dummy = dummy * scale_factor
  )

  shade_df <- data.frame(
    xmin = as.Date(start_date),
    xmax = as.Date(end_date)
  )

  ggplot(plot_df, aes(date)) +
    geom_rect(
      data = shade_df, inherit.aes = FALSE,
      aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf),
      fill = "firebrick", alpha = 0.10
    ) +
    geom_line(aes(y = value, color = "Series")) +
    geom_line(aes(y = dummy, color = "Window dummy (scaled)"),
      linetype = "dashed"
    ) +
    geom_hline(yintercept = 0, color = "grey70", linetype = "dotted") +
    scale_color_manual(values = c(
      "Series" = "steelblue",
      "Window dummy (scaled)" = "firebrick"
    )) +
    labs(title = title, x = NULL, y = value_col, color = NULL) +
    theme_minimal() +
    theme(legend.position = "bottom")
}
