# R/plots.R
.data <- rlang::.data

#' Plot all series on faceted panels
#'
#' @param df Long-format tibble: series_id, date, value, country, indicator
#' @param value_col Name of the column to plot (default "value")
#'
plot_series_facet <- function(df, value_col = "value") {
  ggplot2::ggplot(
    df,
    ggplot2::aes(x = .data$date, y = .data[[value_col]], colour = .data$country)
  ) +
    ggplot2::geom_line(linewidth = 0.6) +
    ggplot2::geom_smooth(
      method = "lm",
      se = FALSE,
      linetype = "dashed",
      linewidth = 0.5
    ) +
    ggplot2::facet_wrap(
      ggplot2::vars(.data$indicator),
      scales = "free_y",
      ncol = 1
    ) +
    ggplot2::scale_x_date(date_breaks = "2 years", date_labels = "%Y") +
    ggplot2::labs(
      x = NULL,
      y = NULL,
      colour = NULL,
      title = "Harmonized unemployment and HICP",
      subtitle = "Denmark and the Eurozone, monthly"
    ) +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(
      legend.position = "top",
      panel.grid.minor = ggplot2::element_blank()
    )
}

#' Plot single indicator
#'
#' @param df Long-format tibble: series_id, date, value, country, indicator
#' @param indicator_name The name of the indicator to be plotted
#' @param value_col Name of the column to plot (default "value")
#'
plot_indicator <- function(df, indicator_name, value_col = "value") {
  df |>
    dplyr::filter(.data$indicator == indicator_name) |>
    ggplot2::ggplot(
      ggplot2::aes(
        x = .data$date,
        y = .data[[value_col]],
        colour = .data$country
      )
    ) +
    ggplot2::geom_line(linewidth = 0.7) +
    ggplot2::geom_smooth(
      method = "lm",
      se = FALSE,
      linetype = "dashed",
      linewidth = 0.5
    ) +
    ggplot2::labs(
      x = NULL, y = NULL, colour = NULL,
      title = indicator_name
    ) +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(legend.position = "top")
}

#' Plot year-over-year change in series
#'
#' @param df Long-format tibble: series_id, date, value, country, indicator
#' @param value_col Name of the column to compute YoY change on
#'
plot_yoy <- function(df, value_col = "value") {
  df |>
    dplyr::group_by(.data$series_id) |>
    dplyr::arrange(.data$date, .by_group = TRUE) |>
    dplyr::mutate(
      yoy = (.data[[value_col]] / dplyr::lag(.data[[value_col]], 12) - 1) * 100
    ) |>
    dplyr::ungroup() |>
    ggplot2::ggplot(
      ggplot2::aes(x = .data$date, y = .data$yoy, colour = .data$country)
    ) +
    ggplot2::geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey50") +
    ggplot2::geom_line(linewidth = 0.6) +
    ggplot2::facet_wrap(
      ggplot2::vars(.data$indicator),
      scales = "free_y",
      ncol = 1
    ) +
    ggplot2::labs(
      x = NULL, y = "% YoY", colour = NULL,
      title = "Year-over-year change"
    ) +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(legend.position = "top")
}

#' Subseries plot: one mini-panel per calendar month
#'
#' Splits each series by month of year and plots the values within each
#' month over time, with a horizontal line at the month's mean. Useful
#' for spotting seasonality: if the lines tilt or the means differ across
#' panels, there's a seasonal pattern.
#'
#' @param df Long-format tibble: series_id, date, value, country, indicator
#' @param indicator_name The indicator to plot (one indicator at a time,
#'   since y-axes aren't comparable across indicators)
#' @param value_col Name of the column to plot (default "value")
#'
plot_subseries <- function(df, indicator_name, value_col = "value") {
  df |>
    dplyr::filter(.data$indicator == indicator_name) |>
    dplyr::mutate(
      month = factor(
        format(.data$date, "%b"),
        levels = month.abb
      )
    ) |>
    dplyr::group_by(.data$country, .data$month) |>
    dplyr::mutate(month_mean = mean(.data[[value_col]], na.rm = TRUE)) |>
    dplyr::ungroup() |>
    ggplot2::ggplot(
      ggplot2::aes(
        x = .data$date, y = .data[[value_col]], colour = .data$country
      )
    ) +
    ggplot2::geom_line(linewidth = 0.5) +
    ggplot2::geom_line(
      ggplot2::aes(y = .data$month_mean),
      colour = "grey30",
      linewidth = 0.4,
      linetype = "dashed"
    ) +
    ggplot2::facet_grid(
      rows = ggplot2::vars(.data$country),
      cols = ggplot2::vars(.data$month),
      scales = "free_y"
    ) +
    ggplot2::scale_x_date(labels = NULL, breaks = NULL) +
    ggplot2::labs(
      x = NULL, y = NULL, colour = NULL,
      title = paste("Subseries plot:", indicator_name),
      subtitle = "Each column is one calendar month; dashed line = month mean"
    ) +
    ggplot2::theme_classic(base_size = 11) +
    ggplot2::theme(
      legend.position = "top",
      panel.grid.minor = ggplot2::element_blank(),
      panel.spacing.x = grid::unit(2, "pt"),
      strip.text.x = ggplot2::element_text(size = 8)
    )
}

# R/plots.R (additions)

#' ACF plot for one or more series, faceted by series
#'
#' @param df Long-format tibble: series_id, date, value, country, indicator
#' @param value_col Column to compute ACF on (default "value")
#' @param lag_max Maximum lag to display (default 36, ~3 years for monthly data)
#' @param indicator_name Optional: filter to a single indicator before plotting
#' @return ggplot object
#'
plot_acf <- function(df, value_col = "value", lag_max = 36,
                     indicator_name = NULL) {
  plot_correlogram(
    df,
    value_col = value_col,
    lag_max = lag_max,
    indicator_name = indicator_name,
    type = "correlation"
  )
}

#' PACF plot for one or more series, faceted by series
#'
#' @inheritParams plot_acf
#'
plot_pacf <- function(df, value_col = "value", lag_max = 36,
                      indicator_name = NULL) {
  plot_correlogram(
    df,
    value_col = value_col,
    lag_max = lag_max,
    indicator_name = indicator_name,
    type = "partial"
  )
}

plot_correlogram <- function(df, value_col, lag_max, indicator_name, type) {
  if (!is.null(indicator_name)) {
    df <- dplyr::filter(df, .data$indicator == indicator_name)
  }

  acf_df <- df |>
    dplyr::group_by(.data$series_id, .data$country, .data$indicator) |>
    dplyr::summarise(
      acf_data = list({
        x <- stats::na.omit(.data[[value_col]])
        out <- stats::acf(x, lag.max = lag_max, type = type, plot = FALSE)
        tibble::tibble(
          lag = as.vector(out$lag),
          acf = as.vector(out$acf),
          ci  = stats::qnorm(0.975) / sqrt(out$n.used)
        )
      }),
      .groups = "drop"
    ) |>
    tidyr::unnest(.data$acf_data)

  if (type == "correlation") {
    acf_df <- dplyr::filter(acf_df, .data$lag > 0)
  }

  y_lab <- if (type == "correlation") "ACF" else "Partial ACF"
  title <- if (type == "correlation") "Autocorrelation" else "Partial autocorrelation"

  # decide faceting from what's actually in the data
  n_ind <- length(unique(acf_df$indicator))
  n_cty <- length(unique(acf_df$country))

  p <- ggplot2::ggplot(
    acf_df,
    ggplot2::aes(x = .data$lag, y = .data$acf, colour = .data$country)
  ) +
    ggplot2::geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey50") +
    ggplot2::geom_hline(
      ggplot2::aes(yintercept = .data$ci),
      linetype = "dashed", linewidth = 0.3, colour = "grey40"
    ) +
    ggplot2::geom_hline(
      ggplot2::aes(yintercept = -.data$ci),
      linetype = "dashed", linewidth = 0.3, colour = "grey40"
    ) +
    ggplot2::geom_segment(
      ggplot2::aes(xend = .data$lag, yend = 0),
      linewidth = 0.6
    ) +
    ggplot2::geom_point(size = 1.4)

  # one indicator: facet by country only; multiple: grid of indicator x country
  if (n_ind > 1 && n_cty > 1) {
    p <- p + ggplot2::facet_grid(
      rows = ggplot2::vars(.data$indicator),
      cols = ggplot2::vars(.data$country),
      scales = "free_y"
    )
  } else if (n_cty > 1) {
    p <- p + ggplot2::facet_wrap(
      ggplot2::vars(.data$country),
      ncol = 1, scales = "free_y"
    )
  } else {
    p <- p + ggplot2::facet_wrap(
      ggplot2::vars(.data$indicator),
      ncol = 1, scales = "free_y"
    )
  }

  p +
    ggplot2::scale_x_continuous(breaks = scales::pretty_breaks(n = 8)) +
    ggplot2::labs(
      x = "Lag", y = y_lab, colour = NULL,
      title = title,
      subtitle = if (!is.null(indicator_name)) indicator_name else NULL
    ) +
    ggplot2::theme_light(base_size = 12) +
    ggplot2::theme(
      legend.position = "top",
      panel.grid.minor = ggplot2::element_blank(),
      strip.background = ggplot2::element_rect(fill = "grey92", colour = NA),
      strip.text = ggplot2::element_text(colour = "grey20")
    )
}

plot_breaks_bp <- function(df, bp_result, value_col = "value") {
  library(ggplot2)

  series <- data.frame(date = df$date, value = df[[value_col]])
  brks <- data.frame(date = bp_result$break_dates)

  # Optional: shade confidence intervals if available
  ci_df <- NULL
  if (!is.null(bp_result$ci)) {
    ci_df <- data.frame(
      lower = df$date[bp_result$ci[, 1]],
      upper = df$date[bp_result$ci[, 3]]
    )
    ci_df <- ci_df[stats::complete.cases(ci_df), , drop = FALSE]
  }

  p <- ggplot(series, aes(date, value)) +
    geom_line(alpha = 0.7) +
    geom_hline(yintercept = 0, linetype = "dotted", alpha = 0.4)

  p + geom_vline(
    data = brks, aes(xintercept = date),
    color = "firebrick", linetype = "dashed", linewidth = 0.6
  ) +
    labs(
      title = sprintf("Detected breaks: %d", bp_result$n_breaks),
      x = NULL, y = value_col
    ) +
    theme_minimal()
}
