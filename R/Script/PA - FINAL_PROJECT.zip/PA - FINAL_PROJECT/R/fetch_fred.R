# R/fetch_fred.R


#' Fetch a single FRED series
#'
#' @param series_id FRED series identifier
#' @return Tibble with columns: series_id, date, value
#'
fetch_fred_series <- function(series_id) {
  raw <- fredr::fredr(series_id = series_id)
  tibble::tibble(
    series_id = series_id,
    date      = raw$date,
    value     = raw$value
  )
}


#' Fetch all project series and combine into a long table
#'
#' @param series_ids A list of FRED series identifiers
#' @return Long dataframe of series
fetch_all_series <- function(series_ids) {
  purrr::map_dfr(series_ids, fetch_fred_series)
}
