# R/fetch_eurostat.R

.data <- rlang::.data

#' Read a single Eurostat "linear" CSV into the canonical long format
#'
#' Eurostat bulk CSVs contain one observation per row with a `geo` dimension,
#' so a single file expands into one series per geo. This returns the same
#' (series_id, date, value) shape used for FRED.
#'
#' @param path Path to the CSV file.
#' @param dataset_code Short tag for this dataset, e.g. "prc_hicp_minr".
#'   Combined with geo to form the series_id, e.g. "prc_hicp_minr__Denmark".
#' @return Tibble with columns series_id, date, value.
fetch_eurostat_csv <- function(path, dataset_code) {
  raw <- readr::read_csv(
    path,
    show_col_types = FALSE,
    na = c("", "NA", ":") # Eurostat uses ":" for missing
  )

  required <- c("geo", "TIME_PERIOD", "OBS_VALUE")
  missing <- setdiff(required, names(raw))
  if (length(missing)) {
    stop(
      sprintf(
        "Missing columns in %s: %s",
        path, paste(missing, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  tibble::tibble(
    series_id = paste(dataset_code, raw$geo, sep = "_"),
    date      = parse_eurostat_date(raw$TIME_PERIOD),
    value     = suppressWarnings(as.numeric(raw$OBS_VALUE))
  ) |>
    dplyr::arrange(.data$series_id, .data$date)
}

#' Parse Eurostat TIME_PERIOD strings into Date (handles YYYY-MM monthly format)
#' @keywords internal
parse_eurostat_date <- function(x) {
  x <- as.character(x)
  monthly <- grepl("^\\d{4}-\\d{2}$", x)
  x[monthly] <- paste0(x[monthly], "-01")
  as.Date(x)
}

#' Fetch multiple Eurostat CSVs and combine
#'
#' @param files Named character vector. Names are dataset codes used to build
#'   series_ids; values are file paths.
fetch_all_eurostat <- function(files) {
  purrr::imap_dfr(files, \(path, code) fetch_eurostat_csv(path, code))
}

#' Attach country / indicators labels to dataframe
#'
#' @param df Dataframe to be labeled
label_series <- function(df) {
  lookup <- tibble::tribble(
    ~series_id, ~country, ~indicator,
    "prc_hicp_minr_Denmark", "Denmark", "Inflation",
    "prc_hicp_minr_European Union - 27 countries (from 2020)", "EU27", "Inflation",
    "une_rt_m_Denmark", "Denmark", "Unemployment",
    "une_rt_m_European Union - 27 countries (from 2020)", "EU27", "Unemployment"
  )
  dplyr::left_join(df, lookup, by = "series_id")
}
