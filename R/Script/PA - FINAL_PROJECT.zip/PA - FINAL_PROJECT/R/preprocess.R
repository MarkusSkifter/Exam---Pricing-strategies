# R/preprocess.R
.data <- rlang::.data

#' Pre-process series to remove deterministic level / trend / seasonality
#'
#' For each series_id, optionally demeans, detrends (linear), and removes
#' deterministic seasonal means (monthly dummies). The output column holds
#' the residual; downstream stationarity tests can then be run with all
#' deterministic switches OFF.
#'
#' @param df Long-format tibble with columns series_id, date, value, indicator
#' @param value_col Input column name (default "value")
#' @param new_col Output column name (default "residual")
#' @param demean_indicators Indicators to demean
#' @param detrend_indicators Indicators to demean + linearly detrend
#' @param deseason_indicators Indicators to additionally remove monthly means
#' @param frequency Seasonal period (12 = monthly)
#' @return df with one extra column named new_col
preprocess_series <- function(df,
                              value_col = "value",
                              new_col = "residual",
                              demean_indicators = character(),
                              detrend_indicators = character(),
                              deseason_indicators = character(),
                              frequency = 12) {
  df |>
    dplyr::arrange(.data$series_id, .data$date) |>
    dplyr::group_by(.data$series_id) |>
    dplyr::mutate(
      !!new_col := {
        v <- .data[[value_col]]
        ind <- dplyr::first(.data$indicator)

        do_demean <- ind %in% demean_indicators ||
          ind %in% detrend_indicators ||
          ind %in% deseason_indicators
        do_detrend <- ind %in% detrend_indicators
        do_deseason <- ind %in% deseason_indicators

        if (!do_demean && !do_detrend && !do_deseason) {
          v
        } else {
          # Build a regression matrix from the requested deterministics
          n <- length(v)
          X <- matrix(1, nrow = n, ncol = 1)
          colnames(X) <- "intercept"
          if (do_detrend) {
            X <- cbind(X, trend = seq_len(n))
          }
          if (do_deseason) {
            # Monthly dummies (drop one to avoid collinearity with intercept)
            month <- as.integer(format(.data$date, "%m"))
            D <- stats::model.matrix(~ factor(month))[, -1, drop = FALSE]
            X <- cbind(X, D)
          }
          ok <- stats::complete.cases(X, v)
          fit <- stats::lm.fit(X[ok, , drop = FALSE], v[ok])
          res <- rep(NA_real_, n)
          res[ok] <- fit$residuals
          res
        }
      }
    ) |>
    dplyr::ungroup()
}
