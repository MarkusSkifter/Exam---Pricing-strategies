# R/residuals_excl_window.R
#
# Given a fitted model and a date window, drop the residuals inside the
# window, then run Ljung-Box on what remains and plot the kept vs excluded
# residuals.

residuals_excl_window <- function(fit, dates, exclude_start, exclude_end,
                                  lags = c(6, 12, 24)) {
  resi <- as.numeric(residuals(fit))
  if (length(resi) != length(dates)) {
    stop("dates and residuals have different lengths")
  }

  excluded <- dates >= as.Date(exclude_start) & dates <= as.Date(exclude_end)
  kept <- resi[!excluded]

  ord <- forecast::arimaorder(fit)
  k <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)

  lb <- vapply(
    lags, function(L) {
      Box.test(kept, lag = L, type = "Ljung-Box", fitdf = k)$p.value
    },
    numeric(1)
  )
  lb_tbl <- data.frame(lag = lags, p_value = lb)

  list(
    residuals_df = data.frame(date = dates, resid = resi, excluded = excluded),
    n_kept       = sum(!excluded),
    n_excluded   = sum(excluded),
    ljung_box    = lb_tbl
  )
}

plot_residuals_excl <- function(out) {
  library(ggplot2)
  ggplot(out$residuals_df, aes(date, resid, color = excluded)) +
    geom_line(aes(group = 1), color = "grey60", alpha = 0.5) +
    geom_point(size = 1) +
    geom_hline(yintercept = 0, linetype = "dashed") +
    scale_color_manual(
      values = c(`FALSE` = "black", `TRUE` = "firebrick"),
      labels = c("kept", "excluded")
    ) +
    labs(
      title = "Residuals with break window excluded",
      x = NULL, y = "residual", color = NULL
    ) +
    theme_minimal() +
    theme(legend.position = "bottom")
}
