# R/gets.R
#
# Helpers for General-to-Specific (GETS) modeling using gets::isat().
#
# Workflow:
#   1. build_lag_matrix()    -> create lag matrices for regressors
#   2. build_gum()           -> assemble the General Unrestricted Model
#   3. fit_gets()            -> run isat() with IIS/SIS
#   4. tidy_gets()           -> extract retained variables + diagnostics
#   5. plot_gets_*()         -> visualizations
#
# Assumes data is on a single tsibble or data frame with a date column.
# All regressors must be I(0). Stationarity is the caller's responsibility.
# --------------------------------------------------------------------------- 80

# 1. Build lag matrix for a single variable
build_lag_matrix <- function(x, max_lag, prefix) {
  n <- length(x)
  mat <- sapply(0:max_lag, function(k) {
    c(rep(NA_real_, k), x[seq_len(n - k)])
  })
  colnames(mat) <- paste0(prefix, "_l", 0:max_lag)
  mat
}

# 2. Build the GUM regressor matrix
#
# vars: named list of numeric vectors (each is a regressor variable).
#       Names become the prefix for the lag columns.
# max_lag: integer, applied to all variables.
# extras: optional matrix of additional regressors (e.g. break dummies)
#         that should NOT be lagged. Columns kept as-is.
build_gum <- function(vars, max_lag = 6, extras = NULL) {
  if (!is.list(vars) || is.null(names(vars))) {
    stop("`vars` must be a named list of numeric vectors")
  }

  lag_mats <- mapply(
    function(x, nm) build_lag_matrix(x, max_lag, nm),
    vars, names(vars),
    SIMPLIFY = FALSE
  )

  gum <- do.call(cbind, lag_mats)
  if (!is.null(extras)) {
    gum <- cbind(gum, extras)
  }
  gum
}

# 3. Run isat with sensible defaults
#
# y: dependent variable (numeric vector)
# gum: GUM regressor matrix from build_gum()
# ar_lags: AR lags to include (default 1:6)
# t_pval: t-statistic threshold (default 0.05)
# use_iis, use_sis: enable impulse / step indicator saturation
fit_gets <- function(y, gum,
                     ar_lags = 1:6,
                     t_pval = 0.05,
                     use_iis = TRUE,
                     use_sis = TRUE) {
  keep <- complete.cases(gum) & !is.na(y)
  y_clean <- y[keep]
  x_clean <- gum[keep, , drop = FALSE]

  fit <- gets::isat(
    y      = y_clean,
    ar     = ar_lags,
    mxreg  = x_clean,
    iis    = use_iis,
    sis    = use_sis,
    t.pval = t_pval
  )

  list(
    fit       = fit,
    y_used    = y_clean,
    x_used    = x_clean,
    keep_idx  = which(keep)
  )
}

# 4. Tidy the retained-variable list
tidy_gets <- function(gets_obj) {
  fit <- gets_obj$fit
  coefs <- coef(fit)

  if (length(coefs) == 0) {
    return(data.frame(
      variable = character(0),
      coefficient = numeric(0),
      std_error = numeric(0),
      t_stat = numeric(0),
      p_value = numeric(0)
    ))
  }

  # gets stores standard errors in $vcov.mean (model variance-covariance matrix)
  se <- if (!is.null(fit$vcov.mean)) sqrt(diag(fit$vcov.mean)) else NA_real_

  out <- data.frame(
    variable = names(coefs),
    coefficient = as.numeric(coefs),
    std_error = if (length(se) == length(coefs)) as.numeric(se) else NA_real_,
    stringsAsFactors = FALSE
  )
  out$t_stat <- out$coefficient / out$std_error
  out$p_value <- 2 * (1 - pnorm(abs(out$t_stat)))
  out
}

# 5a. Plot retained coefficients with error bars
plot_gets_coefs <- function(gets_obj, title = "GETS retained coefficients") {
  tidy <- tidy_gets(gets_obj)
  if (nrow(tidy) == 0) {
    message("No retained coefficients to plot.")
    return(invisible(NULL))
  }

  tidy$variable <- factor(tidy$variable, levels = tidy$variable[order(tidy$coefficient)])

  ggplot2::ggplot(tidy, ggplot2::aes(x = coefficient, y = variable)) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = "grey50") +
    ggplot2::geom_point(color = "steelblue", size = 2.5) +
    ggplot2::geom_errorbarh(
      ggplot2::aes(
        xmin = coefficient - 1.96 * std_error,
        xmax = coefficient + 1.96 * std_error
      ),
      height = 0.2, color = "steelblue", alpha = 0.6
    ) +
    ggplot2::labs(
      title = title,
      x = "Coefficient (95% CI)",
      y = NULL
    ) +
    ggplot2::theme_minimal()
}

# 5b. Plot fitted vs actual
plot_gets_fit <- function(gets_obj, dates,
                          title = "GETS: fitted vs actual") {
  fitted_vals <- as.numeric(fitted(gets_obj$fit))
  actual_vals <- as.numeric(gets_obj$y_used)
  n_fit <- length(fitted_vals)

  # Take the LAST n_fit dates and y values - isat drops the first max(ar) rows
  dates_used <- dates[gets_obj$keep_idx]
  dates_fit <- tail(dates_used, n_fit)
  actual_fit <- tail(actual_vals, n_fit)

  df <- data.frame(
    date   = dates_fit,
    actual = actual_fit,
    fitted = fitted_vals
  )

  ggplot2::ggplot(df, ggplot2::aes(x = date)) +
    ggplot2::geom_line(ggplot2::aes(y = actual, color = "Actual"), size = 0.5) +
    ggplot2::geom_line(ggplot2::aes(y = fitted, color = "Fitted"),
      size = 0.7, alpha = 0.8
    ) +
    ggplot2::scale_color_manual(
      name = NULL,
      values = c("Actual" = "black", "Fitted" = "steelblue")
    ) +
    ggplot2::labs(title = title, x = NULL, y = "Value") +
    ggplot2::theme_minimal()
}

plot_gets_residuals <- function(gets_obj, dates,
                                title = "GETS: residuals") {
  resid_vals <- as.numeric(residuals(gets_obj$fit))
  n_res <- length(resid_vals)

  dates_used <- dates[gets_obj$keep_idx]
  dates_res <- tail(dates_used, n_res)

  df <- data.frame(date = dates_res, residual = resid_vals)

  ggplot2::ggplot(df, ggplot2::aes(x = date, y = residual)) +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
    ggplot2::geom_line(color = "steelblue") +
    ggplot2::labs(title = title, x = NULL, y = "Residual") +
    ggplot2::theme_minimal()
}

# 5d. Plot detected indicators (IIS pulses and SIS steps) on the series
plot_gets_indicators <- function(gets_obj, dates,
                                 title = "GETS: detected indicators") {
  coefs <- coef(gets_obj$fit)
  names_coefs <- names(coefs)

  # IIS indicators: "iis" followed by position number
  iis_idx <- grep("^iis", names_coefs)
  # SIS indicators: "sis" followed by position number
  sis_idx <- grep("^sis", names_coefs)

  dates_used <- dates[gets_obj$keep_idx]
  y_used <- as.numeric(gets_obj$y_used)

  df_y <- data.frame(date = dates_used, value = y_used)

  p <- ggplot2::ggplot(df_y, ggplot2::aes(x = date, y = value)) +
    ggplot2::geom_line(color = "black") +
    ggplot2::labs(title = title, x = NULL, y = "Value") +
    ggplot2::theme_minimal()

  if (length(iis_idx) > 0) {
    iis_positions <- as.integer(gsub("iis", "", names_coefs[iis_idx]))
    iis_dates <- dates_used[iis_positions]
    p <- p + ggplot2::geom_vline(
      xintercept = iis_dates,
      color = "red", linetype = "dotted", alpha = 0.6
    )
  }

  if (length(sis_idx) > 0) {
    sis_positions <- as.integer(gsub("sis", "", names_coefs[sis_idx]))
    sis_dates <- dates_used[sis_positions]
    p <- p + ggplot2::geom_vline(
      xintercept = sis_dates,
      color = "blue", linetype = "dashed", alpha = 0.6
    )
  }

  p
}

format_gets_table <- function(retained, digits = 3, gap = 4) {
  stars <- function(p) {
    ifelse(p < 0.001, "***",
      ifelse(p < 0.01, "** ",
        ifelse(p < 0.05, "*  ",
          ifelse(p < 0.10, ".  ", "   ")
        )
      )
    )
  }

  group_of <- function(v) {
    ifelse(v == "mconst", "Constant",
      ifelse(grepl("^ar\\d+$", v), "AR",
        ifelse(grepl("^eu_infl_l", v), "EU inflation",
          ifelse(grepl("^dk_unemp_l", v), "DK unemployment",
            ifelse(grepl("^eu_unemp_l", v), "EU unemployment",
              ifelse(grepl("^iis\\d+$", v), "IIS dummy",
                ifelse(grepl("^sis\\d+$", v), "SIS dummy", "Other")
              )
            )
          )
        )
      )
    )
  }

  df <- data.frame(
    group = group_of(retained$variable),
    variable = retained$variable,
    coef = sprintf(paste0("%.", digits, "f"), retained$coefficient),
    se = sprintf(paste0("(%.", digits, "f)"), retained$std_error),
    t = sprintf("%.2f", retained$t_stat),
    p = ifelse(retained$p_value < 0.001, "<0.001",
      sprintf("%.3f", retained$p_value)
    ),
    sig = stars(retained$p_value),
    stringsAsFactors = FALSE
  )

  # Compute column widths: max of header and contents
  headers <- c(
    group = "Group", variable = "Variable", coef = "Coef",
    se = "SE", t = "t", p = "p", sig = ""
  )
  widths <- vapply(
    names(df),
    function(col) max(nchar(c(headers[col], df[[col]]))),
    integer(1)
  )

  # Right-align numeric columns, left-align text
  align <- c(
    group = "left", variable = "left", coef = "right",
    se = "left", t = "right", p = "right", sig = "left"
  )

  pad <- function(x, w, side) {
    formatC(x,
      width = w,
      flag = if (side == "left") "-" else ""
    )
  }

  sep <- strrep(" ", gap)

  # Header
  hdr <- paste(mapply(pad, headers[names(df)], widths, align[names(df)]),
    collapse = sep
  )
  rule <- strrep("-", nchar(hdr))
  cat(hdr, "\n", rule, "\n", sep = "")

  # Rows, with a blank line between groups
  prev_group <- NA
  for (i in seq_len(nrow(df))) {
    if (!is.na(prev_group) && df$group[i] != prev_group) {
      cat(strrep(" ", nchar(hdr)), "\n", sep = "")
    }
    row_str <- paste(
      mapply(
        pad,
        as.character(df[i, ]), widths, align[names(df)]
      ),
      collapse = sep
    )
    cat(row_str, "\n", sep = "")
    prev_group <- df$group[i]
  }
  cat(rule, "\n", sep = "")
  cat("Signif: *** p<0.001  ** p<0.01  * p<0.05  . p<0.10\n")

  invisible(df)
}
