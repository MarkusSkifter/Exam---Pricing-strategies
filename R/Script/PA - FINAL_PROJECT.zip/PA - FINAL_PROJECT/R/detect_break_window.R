# R/detect_break_window.R
#
# detect_break_window() returns the *interval* during which a structural
# break is "active" — both the onset and the return to baseline — rather
# than just a single break date.
#
# Strategy: run Bai-Perron to find all break points, then take consecutive
# pairs as candidate windows. The "active" window is the segment whose
# mean is most different from the surrounding regime.

detect_break_window <- function(df, value_col = "value", h = 0.15,
                                breaks = NULL) {
  ts_y <- ts(df[[value_col]],
    start = c(
      as.numeric(format(min(df$date), "%Y")),
      as.numeric(format(min(df$date), "%m"))
    ),
    frequency = 12
  )

  bp <- strucchange::breakpoints(ts_y ~ 1, h = h, breaks = breaks)
  idx <- bp$breakpoints
  if (any(is.na(idx)) || length(idx) < 1) {
    return(list(start = NA, end = NA, segments = NULL, bp = bp))
  }

  # Build segments: [1 .. b1], [b1+1 .. b2], ..., [bk+1 .. n]
  bounds <- c(0, idx, length(df[[value_col]]))
  segs <- data.frame(
    seg        = seq_len(length(bounds) - 1),
    start_idx  = bounds[-length(bounds)] + 1,
    end_idx    = bounds[-1]
  )
  segs$start_date <- df$date[segs$start_idx]
  segs$end_date <- df$date[segs$end_idx]
  segs$seg_mean <- mapply(
    function(a, b) {
      mean(df[[value_col]][a:b], na.rm = TRUE)
    },
    segs$start_idx, segs$end_idx
  )
  segs$seg_sd <- mapply(
    function(a, b) {
      sd(df[[value_col]][a:b], na.rm = TRUE)
    },
    segs$start_idx, segs$end_idx
  )

  # The "active" segment is the one with the largest absolute mean
  # OR the largest SD — pick whichever deviates most from the median segment.
  baseline_mean <- median(segs$seg_mean, na.rm = TRUE)
  baseline_sd <- median(segs$seg_sd, na.rm = TRUE)
  segs$dev_mean <- abs(segs$seg_mean - baseline_mean)
  segs$dev_sd <- abs(segs$seg_sd - baseline_sd)
  segs$score <- segs$dev_mean / max(segs$dev_mean) +
    segs$dev_sd / max(segs$dev_sd)
  active <- segs[which.max(segs$score), ]

  list(
    start    = active$start_date,
    end      = active$end_date,
    segments = segs,
    bp       = bp
  )
}
