# R/clean.R

.data <- rlang::.data

#' Restrict a long-format series tibble to the common date range
#'
#' For each series in 'df', finds the first and last non-NA observation.
#' Returns the data filered to tehe intersectionof all series' ranges.
#'
#' @param df Long-format tibble with columns: series_id, date, value
#' @return Same shape long-format tibble, filtered to common window
#'

align_common_window <- function(df) {
  ranges <- df |>
    dplyr::filter(!is.na(.data$value)) |>
    dplyr::group_by(.data$series_id) |>
    dplyr::summarise(
      start = min(.data$date),
      end = max(.data$date),
      .groups = "drop"
    )

  print(ranges)

  common_start <- max(ranges$start)
  common_end <- min(ranges$end)

  message(
    "Common range: ", common_start, " to ", common_end,
    " (", nrow(ranges), " series)"
  )
  df |>
    dplyr::filter(.data$date >= common_start, .data$date <= common_end)
}

to_tsiblle <- function(df) {
  tsibble::as_tsibble(df, key = .data$series_id, index = .data$date)
}


#' Convert HICP index to year-over-year inflation rate (%)
#'
#' Replaces the `value` column for HICP rows with
#'   pi_t = 100 * (HICP_t / HICP_{t-12} - 1).
#' Other indicators pass through unchanged. The first 12 observations
#' per HICP series become NA (no t-12 available).
#'
#' @param df Long-format tibble with columns: series_id, date, value, indicator
#' @return Same shape tibble with HICP values transformed
#'
hicp_to_inflation <- function(df) {
  df |>
    dplyr::arrange(.data$series_id, .data$date) |>
    dplyr::group_by(.data$series_id) |>
    dplyr::mutate(
      value = dplyr::if_else(
        .data$indicator == "hicp",
        100 * (.data$value / dplyr::lag(.data$value, 12) - 1),
        .data$value
      )
    ) |>
    dplyr::ungroup()
}
