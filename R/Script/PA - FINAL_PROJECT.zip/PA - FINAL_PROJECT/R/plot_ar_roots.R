# R/plot_ar_roots.R

extract_cycles <- function(fit, min_period = 2, max_period = NULL) {
  ar <- fit$model$phi
  if (length(ar) == 0) {
    return(data.frame())
  }
  roots <- polyroot(c(1, -ar))

  modulus <- Mod(roots)
  arg <- Arg(roots) # angle in radians, in (-pi, pi]
  period <- 2 * pi / abs(arg)

  # Keep only genuine cycles: nonzero imaginary part and finite period
  keep <- abs(Im(roots)) > 1e-6 & is.finite(period) & period >= min_period
  if (!is.null(max_period)) keep <- keep & period <= max_period

  data.frame(
    real    = Re(roots)[keep],
    imag    = Im(roots)[keep],
    modulus = modulus[keep],
    period  = period[keep],
    damping = 1 / modulus[keep] # how fast the cycle decays per step
  )
}

plot_ar_roots <- function(fit, title = NULL) {
  ar <- fit$model$phi
  roots <- if (length(ar)) polyroot(c(1, -ar)) else complex()
  df <- data.frame(
    real = Re(roots), imag = Im(roots),
    modulus = Mod(roots)
  )
  df$inside_unit <- df$modulus < 1 # would indicate non-stationarity

  theta <- seq(0, 2 * pi, length.out = 200)
  circle <- data.frame(x = cos(theta), y = sin(theta))

  ggplot() +
    geom_path(data = circle, aes(x, y), color = "grey60") +
    geom_hline(yintercept = 0, color = "grey80") +
    geom_vline(xintercept = 0, color = "grey80") +
    geom_point(
      data = df, aes(real, imag, color = inside_unit),
      size = 3
    ) +
    scale_color_manual(
      values = c(
        `FALSE` = "steelblue",
        `TRUE` = "firebrick"
      ),
      labels = c(
        "outside (stationary)",
        "inside (non-stationary)"
      )
    ) +
    coord_fixed() +
    labs(
      title = title %||% "AR characteristic roots",
      x = "Re", y = "Im", color = NULL
    ) +
    theme_minimal() +
    theme(legend.position = "bottom")
}

`%||%` <- function(a, b) if (is.null(a)) b else a
