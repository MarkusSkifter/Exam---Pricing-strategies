# analysis/06_fit_and_forecast.R


#' --- Setup ---------------------------------------------------------------- 80
#'
source("R/setup.R")

stat_data <- readRDS("data/processed/stationary.rds")

COVID_START <- as.Date("2021-04-01")
FORECAST_START <- as.Date("2024-01-01")


#' ========================================================================== 80
#' FIT (pre-COVID, detrended) AND FORECAST FROM 2024
#' ========================================================================== 80
#' Recipe:
#'    1) Take full Denmark Inflation, sort by date.
#'    2) Detrend the pre-COVID portion only - this is just to give
#'       auto.arima a stationary, mean-zero input. The trend is a tool
#'       to fit, not a component of the model.
#'    3) Fit auto.arima with d=0, D=0 on the detrended pre-COVID data.
#'    4) Apply the trained parameters to all data through FORECAST_START
#'       using RAW d1_value (no detrending, no trend back). The full
#'       series is approximately mean-stationary, so feeding raw values
#'       directly is consistent with the model's mean-zero assumption.
#'       This conditions the model's state on the COVID episode without
#'       re-estimating any parameters.
#'    5) Forecast from FORECAST_START onwards.
#'
#' Why no trend added back: the linear trend captured in step 2 was
#' fitted on pre-COVID data only, where d1_value happened to drift
#' downward. It is not a structural component of inflation differences.
#' The full series mean is approximately zero, so the model's mean-zero
#' forecasts can be compared to raw d1_value directly.
#'

#' --- Data and splits ------------------------------------------------------ 80
#'
df_full <- subset(
  stat_data,
  country == "Denmark" & indicator == "Inflation"
)
df_full <- df_full[order(df_full$date), ]

df_train <- df_full[df_full$date < COVID_START, ] # for fitting
df_state <- df_full[df_full$date < FORECAST_START, ] # for conditioning
df_test <- df_full[df_full$date >= FORECAST_START, ] # for evaluation

n_train <- nrow(df_train)
h_out <- nrow(df_test)

cat(
  "Train (for ARMA fit):  ",
  as.character(min(df_train$date)), "to",
  as.character(max(df_train$date)),
  "(n =", n_train, ", detrended)\n"
)
cat(
  "State (conditioning):  ",
  as.character(min(df_state$date)), "to",
  as.character(max(df_state$date)),
  "(n =", nrow(df_state), ", raw d1_value)\n"
)
cat(
  "Test (forecast):       ",
  as.character(min(df_test$date)), "to",
  as.character(max(df_test$date)),
  "(n =", h_out, ")\n\n"
)


#' --- Detrend pre-COVID train (fitting prep only) -------------------------- 80
#'
df_train$t <- seq_len(n_train)
trend_lm <- lm(d1_value ~ t, data = df_train)
df_train$clean <- as.numeric(residuals(trend_lm))

cat(sprintf(
  "Pre-COVID trend slope: %.5f per month (p = %.3g)\n",
  coef(trend_lm)["t"],
  summary(trend_lm)$coefficients["t", "Pr(>|t|)"]
))
cat("(Slope used only to make training data mean-zero. Not added back.)\n\n")


#' --- Fit auto.arima ------------------------------------------------------- 80
#'
mod_train <- NULL
invisible(capture.output(
  mod_train <- fit_arima_baseline(df_train,
    value_col = "clean",
    d = 0, D = 0
  )
))
fit_train <- mod_train$fit


#' --- Model summary -------------------------------------------------------- 80
#'
ord <- forecast::arimaorder(fit_train)
arma_total <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)
ar_coefs <- coef(fit_train)[grep("^ar", names(coef(fit_train)))]

if (length(ar_coefs) > 0) {
  roots <- polyroot(c(1, -ar_coefs))
  moduli <- Mod(roots)
  args <- Arg(roots)
  periods <- ifelse(abs(args) < 1e-8, Inf, 2 * pi / abs(args))
} else {
  moduli <- numeric(0)
  periods <- numeric(0)
}

cat("=========================================================\n")
cat("FITTED MODEL\n")
cat("=========================================================\n")
cat(
  "Order        :", ord["p"], ord["d"], ord["q"],
  "(", ord["P"], ord["D"], ord["Q"], ")",
  " total ARMA =", arma_total, "\n"
)
cat(
  "AIC          :", round(AIC(fit_train), 2),
  " | BIC:", round(BIC(fit_train), 2), "\n"
)
cat("Ljung-Box @12:", round(mod_train$ljung_box_12, 4), "\n")
cat("Ljung-Box @24:", round(mod_train$ljung_box_24, 4), "\n")
if (length(moduli) > 0) {
  cat("AR roots:\n")
  for (i in seq_along(moduli)) {
    cat(sprintf(
      "   |root| = %.3f   period = %s\n",
      moduli[i],
      if (is.infinite(periods[i])) {
        "Inf (real root)"
      } else {
        sprintf("%.2f months", periods[i])
      }
    ))
  }
}
cat("=========================================================\n\n")


#' --- Apply trained parameters to state data ------------------------------- 80
#'
#' Feed RAW d1_value (full series up to FORECAST_START) to the trained
#' model. AR/MA coefficients stay fixed; the state is updated based on
#' the new observations including the COVID episode.
#'
y_state <- ts(
  df_state$d1_value,
  start = c(
    as.numeric(format(min(df_state$date), "%Y")),
    as.numeric(format(min(df_state$date), "%m"))
  ),
  frequency = 12
)

mod_state <- forecast::Arima(y_state, model = fit_train)


#' --- Forecast from FORECAST_START ----------------------------------------- 80
#'
fc <- forecast::forecast(mod_state, h = h_out, level = c(80, 95))

forecast_df <- data.frame(
  date   = df_test$date,
  actual = df_test$d1_value,
  fcst   = as.numeric(fc$mean),
  lo80   = as.numeric(fc$lower[, "80%"]),
  hi80   = as.numeric(fc$upper[, "80%"]),
  lo95   = as.numeric(fc$lower[, "95%"]),
  hi95   = as.numeric(fc$upper[, "95%"])
)
forecast_df$error <- forecast_df$actual - forecast_df$fcst


#' --- Accuracy ------------------------------------------------------------- 80
#'
mae <- mean(abs(forecast_df$error))
rmse <- sqrt(mean(forecast_df$error^2))
hit80 <- mean(forecast_df$actual >= forecast_df$lo80 &
  forecast_df$actual <= forecast_df$hi80)
hit95 <- mean(forecast_df$actual >= forecast_df$lo95 &
  forecast_df$actual <= forecast_df$hi95)

cat("--- Out-of-sample accuracy ---\n")
cat(sprintf("MAE:          %.4f\n", mae))
cat(sprintf("RMSE:         %.4f\n", rmse))
cat(sprintf("80%% coverage: %.1f%%  (nominal 80%%)\n", 100 * hit80))
cat(sprintf("95%% coverage: %.1f%%  (nominal 95%%)\n", 100 * hit95))
cat("\n")


#' --- Plot ----------------------------------------------------------------- 80
#'
#' Show the last 24 months of state data + actuals + forecast.
#'
recent <- tail(df_state, 24)

ggplot() +
  geom_line(
    data = recent,
    aes(x = date, y = d1_value), color = "black"
  ) +
  geom_line(
    data = forecast_df,
    aes(x = date, y = actual), color = "black"
  ) +
  geom_ribbon(
    data = forecast_df,
    aes(x = date, ymin = lo95, ymax = hi95),
    fill = "seagreen4", alpha = 0.2
  ) +
  geom_ribbon(
    data = forecast_df,
    aes(x = date, ymin = lo80, ymax = hi80),
    fill = "seagreen4", alpha = 0.4
  ) +
  geom_line(
    data = forecast_df,
    aes(x = date, y = fcst),
    color = "seagreen4", linewidth = 1
  ) +
  geom_vline(
    xintercept = max(df_state$date),
    linetype = "dashed", color = "grey50"
  ) +
  labs(
    title = "Denmark inflation: forecast from 2024",
    subtitle = paste(
      "Trained on detrended pre-COVID (",
      format(max(df_train$date), "%Y-%m"),
      "). State conditioned on raw d1_value through ",
      format(max(df_state$date), "%Y-%m"),
      ". No trend added back.",
      sep = ""
    ),
    x = NULL,
    y = "d1_value"
  ) +
  theme_minimal()
