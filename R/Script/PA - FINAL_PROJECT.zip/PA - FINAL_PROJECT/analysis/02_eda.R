# analysis/02_eda.R


#' --- Setup -----------------------------------------------------------
#'
#' Run setup file and define paths
#'
source("R/setup.R")
aligned_path <- "data/processed/aligned.rds"
stationary_path <- "data/processed/stationary.rds"

#' --- Data import -----------------------------------------------------
#'
#' Import data and transform to timeseries datatype
#'
aligned_data <- readRDS(aligned_path) |>
  hicp_to_inflation() |>
  na.omit()

aligned_data_ts <- aligned_data |>
  to_tsiblle()

#' --- Stationarity ----------------------------------------------------
#'
#' Check for stationarity
#' Remove levels and deterministic seasonality
#'
stationary_ts_summary(
  aligned_data_ts,
  value_col = "value",
  level = FALSE,
  trend = FALSE
)

clean_data <- aligned_data |>
  preprocess_series(
    demean_indicators = c("Inflation", "Unemployment"),
    deseason_indicators = "Unemployment",
    new_col = "residual"
  )

#'
#' Take first differences on unemployment data
#'
to_diff <- clean_data |> dplyr::filter(!indicator %in% c(
  "Inflation"
))

no_diff <- clean_data |> dplyr::filter(indicator %in% c(
  "Inflation"
))

stationary_data <- to_diff |>
  difference_series(
    lag = 1, value_col = "residual", new_col = "d1_value"
  ) |>
  dplyr::bind_rows(
    no_diff |> dplyr::mutate(d1_value = residual)
  ) |>
  na.omit() |>
  align_common_window()


#'
#' Stationary test
#'
stationary_ts_summary(
  stationary_data,
  value_col = "d1_value",
  level = FALSE,
  trend = FALSE
)

#' --- Save data -------------------------------------------------------
#'
#' Save statioinary data
#'
saveRDS(stationary_data, stationary_path)
