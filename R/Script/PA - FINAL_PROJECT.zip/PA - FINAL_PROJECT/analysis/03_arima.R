# analysis/03_arima.R


#' --- Setup ---------------------------------------------------------------- 80
#'
#' Run setup file and define paths
#'
source("R/setup.R")
stationary_path <- "data/processed/stationary.rds"

#' --- Data import ---------------------------------------------------------- 80
#'
#' Import stationary data and split dataframes by country and indicator
#'
split_by_country_indicator <- function(df) {
  splits <- split(df, list(df$country, df$indicator), drop = TRUE)
  names(splits) <- gsub("\\.", "_", names(splits))
  splits
}

stat_data <- readRDS(stationary_path)

stat_split_data <- split_by_country_indicator(stat_data)


#' ========================================================================== 80
#' MODEL FIT
#' ========================================================================== 80
#' Workflow
#'    1)   Detect breakpoints using QLR and Bai-Perron
#'    2)   Fit models
#'    2.1)    Estimate ARIAMX model usign single QLR break
#'    2.2)    Estimate ARIAMX model usign multiple Bai-Perron breaks
#'    3)   Check model fit
#'    4)   Adjust residuals to exclude covid regime
#'

#' --- Baseline ARIMA ------------------------------------------------------- 80
#'
#' Fit ARIMA without xreg variables
#'
arima_fit <- fit_arima_baseline(
  stat_split_data$Denmark_Inflation,
  value_col = "d1_value"
)

#' --- Breakpoint detection ------------------------------------------------- 80
#'
#' Use QLR to find a regieme change in data
#' Use Bai-Perron to find several break-points
#'
qlr_br <- detect_break_qlr(
  stat_split_data$Denmark_Inflation,
  value_col = "d1_value"
)

bp_br <- detect_breaks_bp(
  stat_split_data$Denmark_Inflation,
  value_col = "d1_value"
)

#' --- ARIMA X model fit ---------------------------------------------------- 80
#'
#' Use QLR to find a regieme change in data
#'
arimax_fit_sb <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  qlr_br$break_date,
  type = "LS",
  value_col = "d1_value"
)

arimax_fit_mb <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = bp_br$break_dates,
  type = "LS",
  value_col = "d1_value"
)

models <- list(
  arima_fit          = arima_fit,
  arimax_fit_sb      = arimax_fit_sb,
  arimax_fit_mb      = arimax_fit_mb
)

for (name in names(models)) {
  mod <- models[[name]]
  ord <- forecast::arimaorder(mod$fit)
  ar_coefs <- coef(mod$fit)[grep("^ar", names(coef(mod$fit)))]
  roots <- polyroot(c(1, -ar_coefs))
  periods <- 2 * pi / abs(Arg(roots))
  cat("\nModel: ", name)
  cat("\nModel order: ", sum(ord[names(ord) != "Frequency"]))
  cat("\nModel terms: ", ord[names(ord) != "Frequency"])
  cat("\nAIC: ", round(AIC(mod$fit), 2))
  cat("\nBIC: ", round(BIC(mod$fit), 2))
  cat("\nLjung-Box @ 12-lags: ", round(mod$ljung_box_12, 4))
  cat("\nLjung-Box @ 24-lags: ", round(mod$ljung_box_24, 4))
  cat("\nAR coef:", ar_coefs)
  cat("\nAR roots:", roots)
  cat("\nAR roots periods:", periods)
  cat("\n")
  cat("\n")
}

#' Observations
#'    Binding condition still seems to be max.order; three of four models sit
#'    exactly at the boundary with identical (4,0,5)(0,0,1) terms regardless
#'    of regressors. AR roots all sit near the unit circle (min moduli 1.09)
#'    suggesting near-integrated behavior the ARMA terms are fitting at high
#'    cost. Ljung-Box passes only marginally for three models; the fourth
#'    fails despite the same parameter budget. This combination - boundary-
#'    saturation, near-unit-circle roots, and identical orders across very
#'    different regressors - is the classic signature of misspecified
#'    differencing rather than genuine complexity.
#'
#'    ADF and KPSS both call the series stationary, but both have low power
#'    near the unit-root boundary, so this is worth probing directly by
#'    re-fitting under forced differencing schemes.


#' ========================================================================== 80
#' DIFFERENCING QUESTION
#' ========================================================================== 80
#'
#' Large parameterization brings into question if differencing was correct
#' Three models are fitted with the multiple-break (MB) regressors to test:
#'    1) MB with regular AND seasonal differencing       (d=1, D=1)
#'    2) MB with regular differencing only               (d=1, D=0)  [baseline]
#'    3) MB with seasonal differencing only              (d=0, D=1)
#' Goal:
#'    Determine whether forcing seasonal differencing or removing regular
#'    differencing reduces the saturated ARMA order. The current models hit
#'    max.order=10 with AR roots near the unit circle, suggesting the ARMA
#'    structure is compensating for misspecified differencing.
#'
arimax_fit_mb_d1D1 <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = bp_br$break_dates,
  type = "LS",
  value_col = "d1_value",
  d = 1, D = 1
)

arimax_fit_mb_d1D0 <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = bp_br$break_dates,
  type = "LS",
  value_col = "d1_value",
  d = 1, D = 0
)

arimax_fit_mb_d0D1 <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = bp_br$break_dates,
  type = "LS",
  value_col = "d1_value",
  d = 0, D = 1
)

diff_models <- list(
  arimax_fit_mb      = arimax_fit_mb,
  arimax_fit_mb_d1D1 = arimax_fit_mb_d1D1,
  arimax_fit_mb_d1D0 = arimax_fit_mb_d1D0,
  arimax_fit_mb_d0D1 = arimax_fit_mb_d0D1
)

for (name in names(diff_models)) {
  mod <- diff_models[[name]]
  ord <- forecast::arimaorder(mod$fit)
  ar_coefs <- coef(mod$fit)[grep("^ar", names(coef(mod$fit)))]
  roots <- if (length(ar_coefs) > 0) polyroot(c(1, -ar_coefs)) else complex(0)
  periods <- if (length(roots) > 0) 2 * pi / abs(Arg(roots)) else numeric(0)

  cat("\nModel: ", name)
  cat("\nModel order: ", sum(ord[names(ord) != "Frequency"]))
  cat("\nModel terms: ", ord[names(ord) != "Frequency"])
  cat("\nAIC: ", round(AIC(mod$fit), 2))
  cat("\nBIC: ", round(BIC(mod$fit), 2))
  cat("\nLjung-Box @ 12-lags: ", round(mod$ljung_box_12, 4))
  cat("\nLjung-Box @ 24-lags: ", round(mod$ljung_box_24, 4))
  cat("\nAR coef:", ar_coefs)
  cat("\nAR roots:", roots)
  cat("\nAR roots moduli:", Mod(roots))
  cat("\nAR roots periods:", periods)
  cat("\n")
  cat("\n")
}
#' Observations
#'    The d1D0 specification dominates the original (d0D0) on every diagnostic:
#'    lower AIC (236.21 vs 236.94), lower BIC (284.44 vs 285.22), and
#'    substantially better Ljung-Box at both lags (0.14 vs 0.09 at lag 12,
#'    0.80 vs 0.40 at lag 24). Total order increases by one parameter, but
#'    the residual diagnostics improve enough that the extra MA term is
#'    clearly earning its place. The two seasonally-differenced alternatives
#'    (d1D1 and d0D1) are decisively worse - AIC jumps by ~50 points and
#'    d0D1's Ljung-Box at lag 12 collapses to 0.0055 - confirming that
#'    seasonal differencing is overdifferencing here.
#'
#'    This resolves the differencing question in favor of d1D0, but the
#'    underlying puzzle remains: the chosen model still saturates max.order
#'    at 11 and has AR roots at modulus 1.087 - still close to the unit
#'    circle. ADF/KPSS suggest stationarity, the better-fitting model
#'    differences once anyway, and the AR component fits near-integrated
#'    behavior. The natural next question is whether the persistence and
#'    high order are genuine features of Danish inflation dynamics, or
#'    whether they are being driven by a specific subset of the sample -
#'    most plausibly the COVID episode, which the existing LS break
#'    regressors may not fully absorb. A subsample refit (dropping the
#'    last 20%, which excludes most of the COVID-era observations) lets
#'    us test this directly. If the model simplifies substantially on the
#'    pre-COVID subsample, the LS regressors are inadequate for COVID and
#'    a different break specification is needed.

#' ========================================================================== 80
#' ROBUSTNESS
#' ========================================================================== 80
#'
#' Refit arimax_fit_mb_d1D0 on the first 80% of observations to test whether
#' model order, AR roots, and coefficients are stable. If the specification
#' shifts substantially when the last 20% is removed, the original fit is
#' being driven by a subset of the sample (likely the COVID episode), which
#' means break/outlier regressors are not fully capturing the dynamics.
#'
n_total <- nrow(stat_split_data$Denmark_Inflation)
n_keep <- floor(0.8 * n_total)

stat_data_sub <- stat_split_data$Denmark_Inflation[seq_len(n_keep), ]

bp_br_sub <- detect_breaks_bp(
  stat_data_sub,
  value_col = "d1_value"
)

arimax_fit_mb_d1D0_sub <- fit_arima_with_break(
  stat_data_sub,
  break_dates = bp_br_sub$break_dates,
  type = "LS",
  value_col = "d1_value",
  d = 1, D = 0
)

robustness_models <- list(
  # arimax_fit_mb_d1D0_full = arimax_fit_mb_d1D0,
  arimax_fit_mb_d1D0_sub = arimax_fit_mb_d1D0_sub
)

for (name in names(robustness_models)) {
  mod <- robustness_models[[name]]
  ord <- forecast::arimaorder(mod$fit)
  ar_coefs <- coef(mod$fit)[grep("^ar", names(coef(mod$fit)))]
  roots <- if (length(ar_coefs) > 0) polyroot(c(1, -ar_coefs)) else complex(0)
  periods <- if (length(roots) > 0) 2 * pi / abs(Arg(roots)) else numeric(0)

  cat("\nModel: ", name)
  cat("\nSample size: ", mod$fit$nobs)
  cat("\nModel order: ", sum(ord[names(ord) != "Frequency"]))
  cat("\nModel terms: ", ord[names(ord) != "Frequency"])
  cat("\nAIC: ", round(AIC(mod$fit), 2))
  cat("\nBIC: ", round(BIC(mod$fit), 2))
  cat("\nLjung-Box @ 12-lags: ", round(mod$ljung_box_12, 4))
  cat("\nLjung-Box @ 24-lags: ", round(mod$ljung_box_24, 4))
  cat("\nAR coef:", round(ar_coefs, 4))
  cat("\nAR roots moduli:", round(Mod(roots), 4))
  cat("\nAR roots periods:", round(periods, 2))
  cat("\n")
  cat("\n")
}

plot_series_facet(stat_data_sub, value_col = "d1_value")
