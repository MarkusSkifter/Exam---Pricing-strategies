# analysis/03_arima.R

#' ========================================================================== 80
#' AUXILLARY CODE
#' ========================================================================== 80
#'
#' --- Setup ---------------------------------------------------------------- 80
#'
#' Run setup file and define paths
#'
source("R/setup.R")
stationary_path <- "data/processed/stationary.rds"

#' --- Data import ---------------------------------------------------------- 80
#'
#' Import stationary data and split dataframes by country and indicator
#'
split_by_country_indicator <- function(df) {
  splits <- split(df, list(df$country, df$indicator), drop = TRUE)
  names(splits) <- gsub("\\.", "_", names(splits))
  splits
}
stat_data <- readRDS(stationary_path)
stat_split_data <- split_by_country_indicator(stat_data)


#' ========================================================================== 80
#' COVID XREG
#' ========================================================================== 80
#'
#' Build a boxcar (window) regressor that is 1 during the COVID inflation
#' surge and 0 elsewhere. This treats the COVID episode as a temporary
#' deviation rather than a permanent level shift, matching the visible
#' shape of the series (returns to pre-COVID baseline by 2024).
#'
plot_covid_window(
  stat_split_data$Denmark_Inflation,
  value_col = "d1_value"
)

arimax_fit_covid <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = as.Date("2021-04-01"),
  end_dates   = as.Date("2023-12-31"),
  type        = "WIN",
  value_col   = "d1_value",
  d           = 1,
  D           = 0
)

arimax_fit_covid_tc <- fit_arima_with_break(
  stat_split_data$Denmark_Inflation,
  break_dates = as.Date("2021-04-01"),
  type        = "TC",
  value_col   = "d1_value",
  d           = 1,
  D           = 0
)

models <- list(
  arima_fit           = arima_fit,
  arimax_fit_mb       = arimax_fit_mb,
  arimax_fit_mb_d1D0  = arimax_fit_mb_d1D0,
  arimax_fit_covid    = arimax_fit_covid,
  arimax_fit_covid_tc = arimax_fit_covid_tc
)


for (name in names(models)) {
  mod <- models[[name]]
  ord <- forecast::arimaorder(mod$fit)
  ar_coefs <- coef(mod$fit)[grep("^ar", names(coef(mod$fit)))]
  roots <- if (length(ar_coefs) > 0) polyroot(c(1, -ar_coefs)) else complex(0)
  periods <- if (length(roots) > 0) 2 * pi / abs(Arg(roots)) else numeric(0)

  cat("\nModel: ", name)
  cat("\nModel order: ", sum(ord[names(ord) != "Frequency"]))
  cat("\nModel terms: ", ord[names(ord) != "Frequency"])
  cat("\nAIC: ", round(AIC(mod$fit), 2))
  cat("\nBIC: ", round(BIC(mod$fit), 2))
  cat("\nLjung-Box @ 12-lags: ", round(mod$ljung_box_12, 4))
  cat("\nLjung-Box @ 24-lags: ", round(mod$ljung_box_24, 4))
  cat("\nAR coef:", ar_coefs)
  cat("\nAR roots:", roots)
  cat("\nAR roots moduli:", Mod(roots))
  cat("\nAR roots periods:", periods)
  cat("\n")
  cat("\n")
}

#' Final model selection
#'    Four ARIMAX specifications are now on the table, all fit on the
#'    differenced series with d = 1, D = 0:
#'
#'           Model                 AIC      BIC    LB12     LB24    Order
#'           arima_fit            234.55   275.40   0.073    0.189   10
#'           arimax_fit_mb        236.94   285.22   0.087    0.400   10
#'           arimax_fit_mb_d1D0   236.21   284.44   0.141    0.804   11
#'           arimax_fit_covid     235.39   279.91   0.167    0.687   11
#'           arimax_fit_covid_tc  234.85   279.38   0.145    0.685   11
#'
#'    All four specifications converge on the same underlying ARMA
#'    structure - two complex AR root pairs with periods ~5.5 and ~3.1,
#'    minimum AR root modulus near 1.07 - indicating the dynamics are
#'    a robust feature of the data rather than an artifact of any one
#'    regressor choice. The COVID-period regressors (window or TC) do
#'    not simplify the ARMA order, because residual diagnostics show
#'    the COVID episode introduces heteroskedasticity that conditional-
#'    mean regressors cannot absorb. We accept this limitation and
#'    select on the conditional-mean diagnostics.
#'
#'    Preferred model: arimax_fit_covid_tc
#'        - Lowest BIC of the COVID-aware models (279.38).
#'        - AIC (234.85) within 0.3 of the unrestricted baseline, and
#'          better than the level-shift specifications.
#'        - Ljung-Box at lag 12 of 0.145 and at lag 24 of 0.685, both
#'          comfortably non-rejecting white-noise residuals.
#'        - TC regressor matches the observed shape of the COVID
#'          inflation episode (spike followed by geometric decay back
#'          to baseline) better than a level-shift or flat-window dummy,
#'          giving the cleanest economic interpretation.
#'        - AR roots all outside the unit circle; cyclical components
#'          at ~3 and ~5.5 months are consistent across specifications.
#'
#'    Caveat: residual variance is ~7x larger during 2021-2023 than
#'    pre-2021 and remains ~3x larger after 2023. Point forecasts are
#'    reliable, but forecast intervals from this model will understate
#'    uncertainty during high-volatility regimes. A GARCH extension on
#'    the residuals would address this; we note the limitation and
#'    proceed.
