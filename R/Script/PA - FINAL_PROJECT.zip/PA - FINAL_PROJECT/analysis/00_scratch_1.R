# analysis/04_diagnose_complexity.R


#' --- Setup ---------------------------------------------------------------- 80
#'
#' R/setup.R sources every helper in R/, so make_break_xreg(),
#' detect_breaks_bp(), select_arima_order(), fit_arima_baseline(), and
#' build_covid_window() are all in scope after this line.
#'
source("R/setup.R")
stationary_path <- "data/processed/stationary.rds"

split_by_country_indicator <- function(df) {
  splits <- split(df, list(df$country, df$indicator), drop = TRUE)
  names(splits) <- gsub("\\.", "_", names(splits))
  splits
}

stat_data <- readRDS(stationary_path)
stat_split_data <- split_by_country_indicator(stat_data)
dk_inf <- stat_split_data$Denmark_Inflation


#' ========================================================================== 80
#' EXHAUSTIVE PERMUTATION DIAGNOSTIC
#' ========================================================================== 80
#' Four levers, ordered arrangements of length 1 to 4:
#'    P(4,1) + P(4,2) + P(4,3) + P(4,4) = 4 + 12 + 24 + 24 = 64
#'
#' Levers:
#'    diff : take an additional difference inside the ARIMA (d=1)
#'    excl : restrict the data to the pre-COVID subsample
#'    bp   : detect Bai-Perron breaks on the CURRENT state and include
#'           them as LS regressors via make_break_xreg(type = "LS")
#'    win  : include the 0/1 COVID window dummy via
#'           make_break_xreg(type = "WIN", end_dates = ...)
#'
#' Constraint: BP and WIN are mutually exclusive. A window dummy already
#' absorbs the COVID episode; layering BP breaks on top would just be
#' fitting LS regressors to whatever variance the window dummy leaves,
#' which is double-counting. Any permutation containing both `bp` and
#' `win` is reported as SKIPPED with no fit run.
#'
#' Surviving permutations (26 of 64):
#'    length 1: 4   (diff, excl, bp, win)
#'    length 2: 10  (12 total minus bp>win and win>bp)
#'    length 3: 12  (24 total minus all 12 containing {bp, win})
#'    length 4: 0   (all 24 contain both bp and win - all skipped)
#'
#' Order-sensitive effect:
#'    bp before excl  -> BP dates from the FULL sample (mostly COVID-era;
#'                       most LS columns will be zero-variance over the
#'                       surviving pre-COVID rows after excl drops them
#'                       and will be auto-dropped)
#'    excl before bp  -> BP dates from the PRE-COVID subsample (likely
#'                       2008 and earlier policy shifts)
#'
#' Pass criteria (all required):
#'    not saturated:  arma_total < max.order - 1  (max.order is 10 in
#'                    select_arima_order, so threshold is arma_total < 9)
#'    healthy roots:  min |AR root| >= 1.3 (or no AR component)
#'    clean LB:       Ljung-Box p >= 0.10 at lag 12 AND lag 24
#'
#' Selection among passing cells:
#'    1. Shortest permutation (= lowest intervention count)
#'    2. Tiebreak: lowest AIC
#'
#' max.order is whatever your select_arima_order() uses internally (10).
#' If a passing cell saturates at that ceiling, raise it in that function
#' and rerun.
#'

#' --- COVID window dates (from R/covid_xreg.R defaults) -------------------- 80
#'
COVID_START <- as.Date("2021-04-01")
COVID_END <- as.Date("2023-12-31")

cat(
  "COVID window:", as.character(COVID_START), "to",
  as.character(COVID_END), "\n\n"
)


#' --- Quiet fit wrapper ---------------------------------------------------- 80
#'
#' select_arima_order() has trace = TRUE for interactive use. With ~26
#' fits in this script that floods the console, so wrap each call to
#' silence the trace without modifying your function.
#'
fit_silent <- function(df, xreg, value_col, d, D) {
  out <- NULL
  invisible(capture.output(
    out <- select_arima_order(df,
      xreg = xreg, value_col = value_col,
      d = d, D = D
    )
  ))
  out
}

ljung <- function(fit, lag) {
  ord <- forecast::arimaorder(fit)
  k <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)
  Box.test(residuals(fit),
    lag = lag, type = "Ljung-Box",
    fitdf = k
  )$p.value
}


#' --- State machine -------------------------------------------------------- 80
#'
init_state <- function() {
  list(
    use_diff  = FALSE,
    use_excl  = FALSE,
    use_bp    = FALSE,
    bp_dates  = as.Date(character()),
    bp_source = NA_character_,
    use_win   = FALSE
  )
}

apply_lever <- function(state, lever) {
  if (lever == "diff") {
    state$use_diff <- TRUE
  } else if (lever == "excl") {
    state$use_excl <- TRUE
  } else if (lever == "bp") {
    if (state$use_excl) {
      data_here <- dk_inf[dk_inf$date < COVID_START, ] |>
        preprocess_series(
          value_col = "d1_value",
          detrend_indicators = "Inflation",
          new_col = "clean"
        ) %>%
        dplyr::select(-residual, -value, -d1_value) %>%
        dplyr::rename(value = clean)
      value_col <- "value"
    } else {
      data_here <- dk_inf
      value_col <- "d1_value"
    }

    bp <- detect_breaks_bp(data_here, value_col = value_col)
    state$use_bp <- TRUE
    state$bp_dates <- bp$break_dates # may be empty
    state$bp_source <- if (state$use_excl) "pre-COVID" else "full"
  } else if (lever == "win") {
    state$use_win <- TRUE
  }
  state
}

#' --- Build final xreg (uses make_break_xreg from R/arima_w_break.R) ------ 80
#'
finalize_xreg <- function(state, data) {
  mats <- list()
  bp_degen <- FALSE
  win_degen <- FALSE

  if (state$use_bp) {
    if (length(state$bp_dates) == 0) {
      bp_degen <- TRUE # no breaks detected
    } else {
      bp_in_range <- state$bp_dates >= min(data$date) &
        state$bp_dates <= max(data$date)
      if (!any(bp_in_range)) {
        bp_degen <- TRUE # all breaks dropped
      } else {
        mats$bp <- make_break_xreg(
          dates = data$date,
          break_dates = state$bp_dates[bp_in_range],
          type = "LS"
        )
      }
    }
  }

  if (state$use_win) {
    in_range <- max(data$date) >= COVID_START &&
      min(data$date) <= COVID_END
    if (!in_range) {
      win_degen <- TRUE # window outside data
    } else {
      mats$win <- make_break_xreg(
        dates = data$date,
        break_dates = COVID_START,
        type = "WIN",
        end_dates = COVID_END
      )
    }
  }

  if (length(mats) == 0) {
    return(list(xreg = NULL, bp_degen = bp_degen, win_degen = win_degen))
  }

  xreg <- do.call(cbind, mats)
  zero_var <- apply(xreg, 2, function(c) var(c) == 0)

  if (state$use_bp && !bp_degen) {
    bp_cols <- grepl("^LS_", colnames(xreg))
    if (any(bp_cols) && all(zero_var[bp_cols])) bp_degen <- TRUE
  }
  if (state$use_win && !win_degen) {
    win_cols <- grepl("^WIN_", colnames(xreg))
    if (any(win_cols) && all(zero_var[win_cols])) win_degen <- TRUE
  }

  xreg <- xreg[, !zero_var, drop = FALSE]
  if (ncol(xreg) == 0) xreg <- NULL

  list(xreg = xreg, bp_degen = bp_degen, win_degen = win_degen)
}


#' --- Permutation generator (no external deps) ----------------------------- 80
#'
perm_k <- function(x, k) {
  if (k == 0) {
    return(list(character(0)))
  }
  if (k == 1) {
    return(lapply(x, function(e) e))
  }
  out <- list()
  for (i in seq_along(x)) {
    for (sp in perm_k(x[-i], k - 1)) {
      out[[length(out) + 1]] <- c(x[i], sp)
    }
  }
  out
}

levers <- c("diff", "excl", "bp", "win")
permutations <- list()
for (k in 1:4) permutations <- c(permutations, perm_k(levers, k))
stopifnot(length(permutations) == 64)


#' --- Row factory ---------------------------------------------------------- 80
#'
empty_row <- function(perm, perm_id, status) {
  data.frame(
    perm_id = perm_id,
    sequence = paste(perm, collapse = ">"),
    length = length(perm),
    status = status,
    sample = NA_character_,
    diff_in = NA, bp_in = NA, bp_source = NA_character_, bp_degen = NA,
    win_in = NA, win_degen = NA,
    n_xreg = NA, nobs = NA,
    p = NA, d_in_model = NA, q = NA,
    arma_total = NA, saturated = NA, min_ar_mod = NA,
    aic = NA, bic = NA, lb12 = NA, lb24 = NA,
    stringsAsFactors = FALSE
  )
}

run_perm <- function(perm, perm_id) {
  if (("bp" %in% perm) && ("win" %in% perm)) {
    return(empty_row(perm, perm_id, "skipped (bp+win not allowed)"))
  }

  state <- init_state()
  for (lev in perm) state <- apply_lever(state, lev)

  data <- if (state$use_excl) {
    dk_inf[dk_inf$date < COVID_START, ]
  } else {
    dk_inf
  }

  fin <- finalize_xreg(state, data)

  fit <- tryCatch(
    fit_silent(data,
      xreg = fin$xreg, value_col = "d1_value",
      d = as.integer(state$use_diff), D = 0
    ),
    error = function(e) {
      message(
        "Fit failed for ", paste(perm, collapse = ">"),
        ": ", conditionMessage(e)
      )
      NULL
    }
  )

  if (is.null(fit)) {
    row <- empty_row(perm, perm_id, "fit failed")
    row$sample <- if (state$use_excl) "pre-COVID" else "full"
    row$diff_in <- state$use_diff
    row$bp_in <- state$use_bp
    row$bp_source <- state$bp_source
    row$bp_degen <- fin$bp_degen
    row$win_in <- state$use_win
    row$win_degen <- fin$win_degen
    return(row)
  }

  ord <- forecast::arimaorder(fit)
  arma_total <- sum(ord[c("p", "q", "P", "Q")], na.rm = TRUE)
  ar_coefs <- coef(fit)[grep("^ar", names(coef(fit)))]
  min_mod <- if (length(ar_coefs) > 0) {
    min(Mod(polyroot(c(1, -ar_coefs))))
  } else {
    Inf
  }

  data.frame(
    perm_id = perm_id,
    sequence = paste(perm, collapse = ">"),
    length = length(perm),
    status = "fitted",
    sample = if (state$use_excl) "pre-COVID" else "full",
    diff_in = state$use_diff,
    bp_in = state$use_bp,
    bp_source = state$bp_source,
    bp_degen = fin$bp_degen,
    win_in = state$use_win,
    win_degen = fin$win_degen,
    n_xreg = if (is.null(fin$xreg)) 0L else ncol(fin$xreg),
    nobs = fit$nobs,
    p = ord["p"],
    d_in_model = ord["d"],
    q = ord["q"],
    arma_total = arma_total,
    saturated = arma_total >= 9, # max.order=10 in your fn
    min_ar_mod = round(min_mod, 3),
    aic = round(AIC(fit), 2),
    bic = round(BIC(fit), 2),
    lb12 = round(ljung(fit, 12), 4),
    lb24 = round(ljung(fit, 24), 4),
    stringsAsFactors = FALSE
  )
}


#' ========================================================================== 80
#' RUN ALL 64 PERMUTATIONS
#' ========================================================================== 80
#' Cached to disk every 5 fits. Delete cache to force a fresh run.
#'
cache_path <- "data/processed/diagnose_perms_cache.rds"
results_list <- if (file.exists(cache_path)) readRDS(cache_path) else list()

t_start <- Sys.time()

for (i in seq_along(permutations)) {
  perm <- permutations[[i]]
  key <- paste(perm, collapse = ">")
  if (!is.null(results_list[[key]])) next

  cat(sprintf("[%2d/%2d] %-25s ... ", i, length(permutations), key))
  flush.console()

  row <- run_perm(perm, i)
  results_list[[key]] <- row

  if (row$status == "fitted") {
    cat(sprintf(
      "arma=%d  min|root|=%s  LB12=%s\n",
      row$arma_total,
      format(row$min_ar_mod, nsmall = 2),
      format(row$lb12, nsmall = 3)
    ))
  } else {
    cat(row$status, "\n")
  }

  if (i %% 5 == 0) saveRDS(results_list, cache_path)
}

saveRDS(results_list, cache_path)
cat(
  "\nTotal runtime:",
  round(difftime(Sys.time(), t_start, units = "mins"), 1), "min\n\n"
)

results <- do.call(rbind, results_list)
rownames(results) <- NULL


#' ========================================================================== 80
#' RESULTS TABLE
#' ========================================================================== 80
#'
cat("\n--- All 64 permutations, sorted by length then AIC ---\n")
results_sorted <- results[order(results$length,
  results$aic,
  na.last = TRUE
), ]
print(
  results_sorted[, c(
    "perm_id", "sequence", "length", "status",
    "sample", "bp_source", "n_xreg",
    "arma_total", "saturated", "min_ar_mod",
    "aic", "lb12", "lb24"
  )],
  row.names = FALSE
)

cat("\nStatus summary:\n")
print(table(results$status))


#' --- Equivalence classes -------------------------------------------------- 80
#'
fitted <- results[results$status == "fitted", ]

fitted$state_key <- with(fitted, paste(
  sample,
  ifelse(diff_in, "d=1", "d=0"),
  ifelse(bp_in & !bp_degen, paste0("bp:", bp_source), "no-bp"),
  ifelse(win_in & !win_degen, "win", "no-win"),
  sep = " | "
))

eq <- aggregate(
  sequence ~ state_key + length + arma_total + min_ar_mod + lb12 + lb24 + aic,
  data = fitted,
  FUN  = function(x) length(x)
)
names(eq)[ncol(eq)] <- "n_perms"

cat("\n--- Equivalence classes among fitted permutations ---\n")
print(eq[order(eq$length, eq$aic), ], row.names = FALSE)


#' ========================================================================== 80
#' SELECTION
#' ========================================================================== 80
#'
select_simplest <- function(res,
                            root_healthy = 1.0,
                            lb_threshold = 0.10) {
  candidates <- res[res$status == "fitted", ]

  passes <- with(
    candidates,
    !saturated &
      (is.infinite(min_ar_mod) | min_ar_mod > root_healthy) &
      lb12 >= lb_threshold & lb24 >= lb_threshold
  )

  candidates$passes <- passes
  passing <- candidates[passes, ]

  cat("\n--- Cells passing all criteria ---\n")
  if (nrow(passing) == 0) {
    cat("NONE.\n\nClosest-passing cells (top 10 by LB at lag 12):\n")
    near <- candidates[order(-candidates$lb12), ]
    print(
      head(near[, c(
        "sequence", "length", "sample", "bp_source",
        "arma_total", "saturated", "min_ar_mod",
        "lb12", "lb24", "aic"
      )], 10),
      row.names = FALSE
    )
    return(NULL)
  }

  print(
    passing[
      order(passing$length, passing$aic),
      c(
        "sequence", "length", "sample", "bp_source", "n_xreg",
        "arma_total", "min_ar_mod", "lb12", "lb24", "aic"
      )
    ],
    row.names = FALSE
  )

  passing[order(passing$length, passing$aic), ][1, ]
}

winner <- select_simplest(results)


#' ========================================================================== 80
#' VERDICT
#' ========================================================================== 80
#'
print_verdict <- function(w) {
  if (is.null(w)) {
    cat("\n=========================================================\n")
    cat("NO PERMUTATION PASSES ALL CRITERIA\n")
    cat("=========================================================\n")
    cat("No reachable specification under these four levers produces\n")
    cat("clean residuals at max.order = 10 (select_arima_order default).\n")
    cat("Options to explore next:\n")
    cat("  - Raise max.order inside select_arima_order(). If the\n")
    cat("    closest-passing cells are at the boundary, this may help.\n")
    cat("  - Otherwise the diagnosis is H4: COVID introduces dynamics\n")
    cat("    no LS/window dummy can absorb. Estimate downstream models\n")
    cat("    on the pre-COVID subsample only.\n")
    cat("=========================================================\n\n")
    return(invisible(NULL))
  }

  cat("\n=========================================================\n")
  cat("SIMPLEST PASSING PERMUTATION:", w$sequence, "\n")
  cat("=========================================================\n")
  cat("Sequence:      ", w$sequence, "(length", w$length, ")\n")
  cat("Sample:        ", w$sample, "\n")
  cat("Differencing:  ", if (w$diff_in) "d=1" else "d=0", "\n")
  cat(
    "BP breaks:     ",
    if (w$bp_in) {
      paste0("yes (detected on ", w$bp_source, ")")
    } else {
      "no"
    }, "\n"
  )
  cat("Window dummy:  ", if (w$win_in) "yes" else "no", "\n")
  cat("xreg columns:  ", w$n_xreg, "\n")
  cat("ARMA order:    ", w$arma_total,
    " | min |AR root|: ", w$min_ar_mod, "\n",
    sep = ""
  )
  cat("AIC:           ", w$aic, "\n")
  cat(
    "Ljung-Box:     ", "lag12 p =", w$lb12,
    " | lag24 p =", w$lb24, "\n"
  )
  cat("---------------------------------------------------------\n")

  cat("DOWNSTREAM RECIPE (GETS / dynamic regression):\n")
  if (w$sample == "pre-COVID") {
    cat(
      "  Restrict the estimation sample to dates <",
      as.character(COVID_START), ".\n"
    )
  } else {
    cat("  Estimate on the full sample.\n")
  }
  if (w$bp_in) {
    cat(
      "  detect_breaks_bp() on the", w$bp_source,
      "sample; build xreg with\n"
    )
    cat("  make_break_xreg(type = \"LS\", break_dates = <those dates>).\n")
  }
  if (w$win_in) {
    cat("  make_break_xreg(type = \"WIN\", break_dates = ",
      as.character(COVID_START), ", end_dates = ",
      as.character(COVID_END), ").\n",
      sep = ""
    )
  }
  if (!w$bp_in && !w$win_in) {
    cat("  No exogenous regressors.\n")
  }
  if (w$diff_in) {
    cat("  d = 1 inside the ARIMA (further differencing of d1_value).\n")
  } else {
    cat("  d = 0 inside the ARIMA (use d1_value as-is).\n")
  }
  cat("=========================================================\n\n")
}

print_verdict(winner)


#' ========================================================================== 80
#' EXPORT
#' ========================================================================== 80
#'
saveRDS(results, "data/processed/diagnose_perms_results.rds")
write.csv(results_sorted,
  "data/processed/diagnose_perms_results.csv",
  row.names = FALSE
)

cat("Saved full results to data/processed/diagnose_perms_results.{rds,csv}\n")
