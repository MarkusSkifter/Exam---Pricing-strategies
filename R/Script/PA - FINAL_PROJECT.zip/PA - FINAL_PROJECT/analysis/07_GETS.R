# analysis/03_arima.R

#' ========================================================================== 80
#' AUXILLARY CODE
#' ========================================================================== 80
#'
#' --- Setup ---------------------------------------------------------------- 80
#'
#' Run setup file and define paths
#'
source("R/setup.R")
stationary_path <- "data/processed/stationary.rds"

#' --- Data import ---------------------------------------------------------- 80
#'
#' Import stationary data and split dataframes by country and indicator
#' Since last few code snippets determined that the data would benefit
#' from further differencing, inflation data is now also differenced
#'
#' Done by selecting inflation as a data series to difference, and then
#' taking differences - then everything besides the new column is removed
#' and the new column is renamed as value
#'
stat_data <- readRDS(stationary_path)

to_diff <- stat_data |> dplyr::filter(!indicator %in% c(
  "Unemployment"
))

no_diff <- stat_data |> dplyr::filter(indicator %in% c(
  "Unemployment"
))

stat_data <- to_diff |>
  difference_series(
    lag = 1, value_col = "d1_value", new_col = "d2_value"
  ) |>
  dplyr::bind_rows(
    no_diff |> dplyr::mutate(d2_value = d1_value)
  ) |>
  na.omit() |>
  align_common_window()

#'
#' Remove unneeded columns
#'
stat_data <- stat_data %>%
  select(-value, -residual, -d1_value) %>%
  rename(value = d2_value)

#'
#' Split data per country
#'
split_by_country_indicator <- function(df) {
  splits <- split(df, list(df$country, df$indicator), drop = TRUE)
  names(splits) <- gsub("\\.", "_", names(splits))
  splits
}

stat_split_data <- split_by_country_indicator(stat_data)

#' ========================================================================== 80
#' GETS MODELING - Denmark inflation
#' ========================================================================== 80
#' Strategy
#'    Build a General Unrestricted Model (GUM) with:
#'      - AR lags 1:6 of dk_inflation
#'      - Contemporaneous + lags 0:6 of: eu_inflation, dk_unemployment,
#'        eu_unemployment (all on stationary scale)
#'    Use isat() with IIS and SIS to:
#'      - Reduce to retained regressors at the 5% level
#'      - Detect outliers (IIS) and additional level shifts (SIS)
#'    Carry the retained specification forward for forecasting.
#'
#' Data preparation:
#'    All four variables are pre-treated for stationarity in 02_stationarity.R:
#'      - DK inflation: differenced, demeaned
#'      - EU inflation: differenced, demeaned
#'      - DK unemployment: differenced, demeaned, deterministic sns removed
#'      - EU unemployment: differenced, demeaned, deterministic sns removed

#' --- Assemble unified data frame ------------------------------------------ 80
#'
#' Join the four series on date so they share a common time index.
#'
join_indicators <- function(stat_split_data, common_col = "value") {
  dk_inf <- stat_split_data$Denmark_Inflation[, c("date", common_col)]
  eu_inf <- stat_split_data$EU27_Inflation[, c("date", common_col)]
  dk_une <- stat_split_data$Denmark_Unemployment[, c("date", common_col)]
  eu_une <- stat_split_data$EU27_Unemployment[, c("date", common_col)]
  names(dk_inf)[2] <- "dk_inflation"
  names(eu_inf)[2] <- "eu_inflation"
  names(dk_une)[2] <- "dk_unemployment"
  names(eu_une)[2] <- "eu_unemployment"

  Reduce(
    function(x, y) merge(x, y, by = "date", all = FALSE),
    list(dk_inf, eu_inf, dk_une, eu_une)
  )
}

gets_data <- join_indicators(stat_split_data)
gets_data <- gets_data[complete.cases(gets_data), ]

cat("Joined data: ", nrow(gets_data), "observations\n")
cat("Date range: ", as.character(range(gets_data$date)), "\n")

#' --- Build the GUM -------------------------------------------------------- 80
#'
#' Regressors to lag: eu_inflation, dk_unemployment, eu_unemployment.
#' Lagged AR terms for dk_inflation are added by isat() via the `ar` argument.
#'
gum_vars <- list(
  eu_infl    = gets_data$eu_inflation,
  dk_unemp   = gets_data$dk_unemployment,
  eu_unemp   = gets_data$eu_unemployment
)

gum_matrix <- build_gum(gum_vars, max_lag = 6, extras = NULL)

cat("GUM matrix dimensions: ", dim(gum_matrix), "\n")
cat("GUM columns:\n")
print(colnames(gum_matrix))

#' --- Fit GETS with IIS and SIS -------------------------------------------- 80
#'
gets_dk_inf <- fit_gets(
  y       = gets_data$dk_inflation,
  gum     = gum_matrix,
  ar_lags = 1:6,
  t_pval  = 0.05,
  use_iis = TRUE,
  use_sis = TRUE
)

#' --- Inspect retained specification --------------------------------------- 80
#'
retained <- tidy_gets(gets_dk_inf)
format_gets_table(retained) |> print(n = Inf)


cat("\nRetained regressors: ", nrow(retained), "\n")
cat("Of which IIS pulses: ", sum(grepl("^iis", retained$variable)), "\n")
cat("Of which SIS steps: ", sum(grepl("^sis", retained$variable)), "\n")
cat("Of which AR lags: ", sum(grepl("^ar", retained$variable)), "\n")

#' --- Visualizations ------------------------------------------------------- 80
#'
p_coefs <- plot_gets_coefs(gets_dk_inf,
  title = "Denmark inflation: retained GETS coefficients"
)
p_fit <- plot_gets_fit(gets_dk_inf, gets_data$date,
  title = "Denmark inflation: GETS fitted vs actual"
)
p_resid <- plot_gets_residuals(gets_dk_inf, gets_data$date,
  title = "Denmark inflation: GETS residuals"
)
p_indic <- plot_gets_indicators(gets_dk_inf, gets_data$date,
  title = "Denmark inflation: detected indicators (red=IIS, blue=SIS)"
)

print(p_coefs)
print(p_fit)
print(p_resid)
print(p_indic)
