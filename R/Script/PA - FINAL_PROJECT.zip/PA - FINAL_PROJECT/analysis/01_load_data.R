# analysis/01_load_data.R

source("R/setup.R")

raw_path <- "data/raw/raw.rds"
aligned_path <- "data/processed/aligned.rds"

eurostat_files <- c(
  prc_hicp_minr = "data/raw/prc_hicp_minr__custom_21465689_linear.csv",
  une_rt_m      = "data/raw/une_rt_m__custom_21465700_linear.csv"
)

eurostat_part <- fetch_all_eurostat(eurostat_files)

raw_data <- label_series(eurostat_part)

saveRDS(raw_data, raw_path)

aligned_data <- align_common_window(raw_data)

saveRDS(aligned_data, aligned_path)

aligned_data
