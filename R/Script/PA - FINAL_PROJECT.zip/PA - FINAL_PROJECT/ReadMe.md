#' DATA
#' ====

https://fred.stlouisfed.org/series/LRHUADTTEZM156N  # Denmark unemployment
https://fred.stlouisfed.org/series/LFHUADTTDKM647N  # Eurozone unemployment
https://fred.stlouisfed.org/series/CP0000DKM086NEST # Denmark HICP  
https://fred.stlouisfed.org/series/CP0000DKM086NEST # Eurozone HICP
